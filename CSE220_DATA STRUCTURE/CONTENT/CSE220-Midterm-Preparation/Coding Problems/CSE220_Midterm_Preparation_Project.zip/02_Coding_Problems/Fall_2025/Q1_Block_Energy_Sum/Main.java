public class Main {
    static int[][] blockEnergySum(int[][] grid,String[][] dir) {
        int m=grid.length,n=grid[0].length;
        int[][] out=new int[m][n];
        for(int i=0;i<m;i++) for(int j=0;j<n;j++) {
            int r=i,c=j,sum=0,dr=0,dc=0;
            String d=dir[i][j];
            if(d.equals("NE")){dr=-1;dc=1;}
            if(d.equals("NW")){dr=-1;dc=-1;}
            if(d.equals("SE")){dr=1;dc=1;}
            if(d.equals("SW")){dr=1;dc=-1;}
            while(r>=0&&r<m&&c>=0&&c<n){sum+=grid[r][c];r+=dr;c+=dc;}
            out[i][j]=sum;
        }
        return out;
    }
    public static void main(String[] args){
        int[][] g={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        String[][] d={{"SE","SE","SW","NE"},{"SW","SW","NE","SE"},{"NW","SW","NE","NW"},{"SE","NW","SW","NE"}};
        int[][] a=blockEnergySum(g,d);for(int[] r:a){for(int x:r)System.out.print(x+" ");System.out.println();}
    }
}
