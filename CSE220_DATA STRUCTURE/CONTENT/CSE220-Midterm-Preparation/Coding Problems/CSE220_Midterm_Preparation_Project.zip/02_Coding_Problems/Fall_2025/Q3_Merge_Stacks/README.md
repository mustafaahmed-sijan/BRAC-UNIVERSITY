# Merge two sorted stacks using only stacks

**Source paper:** Fall 2025  
**Run:** `javac Main.java` then `java Main`

## 1. Problem explanation (বাংলা)
প্রশ্নটি merge two sorted stacks using only stacks করতে বলছে। Input structure-এর order এবং question paper-এ দেওয়া restriction মেনে output তৈরি করতে হবে।

## 2. Logic breakdown (বাংলা)
দুই stack-এর top থেকে value নিয়ে temporary stack-এ descending collection করি; শেষে transfer করলে top-to-bottom non-decreasing order পাওয়া যায়।

ধাপে ধাপে চিন্তা:
1. প্রথমে input-এর structure এবং কোন node/index top/front/head তা বুঝি।
2. প্রয়োজনীয় pointer বা temporary stack/queue তৈরি করি—শুধু প্রশ্নে অনুমোদিত structure ব্যবহার করি।
3. প্রতিটি iteration-এ condition check করি।
4. কাজ শেষে updated structure/answer return বা print করি।

## 3. Dry run
নিজের sample দিয়ে প্রথম 3–4 iteration হাতে trace করো। প্রতিটি ধাপে `current`, `next`, `prev`, `top` বা `front/back`-এর মান লিখে রাখো। এই problem-এর Java `main` method-এ একটি runnable sample আছে।

## 4. Code walkthrough
`Main.java`-তে solution method-এর পাশে গুরুত্বপূর্ণ operation-এ English comments দেওয়া আছে। `main()` driver দিয়ে code independently run করা যায়।

## 5. Complexity
- **Time:** সাধারণত traversal-ভিত্তিক; nested scan হলে O(n²), একবার scan হলে O(n)। নির্দিষ্ট implementation-এর loop count দেখে যাচাই করো।
- **Space:** output/temporary stack বা queue থাকলে তার size অনুযায়ী O(n); in-place pointer rearrangement হলে O(1) auxiliary space।

## 6. Exam variations
- Empty input / one-node input
- First বা last index boundary
- Duplicate values
- Odd number of elements
- Maximum/minimum values and invalid boundaries
