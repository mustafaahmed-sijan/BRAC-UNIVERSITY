import java.util.Stack;
public class Main {
    static Stack<Integer> mergeStacks(Stack<Integer> a,Stack<Integer> b) {
        Stack<Integer> temp=new Stack<>(), out=new Stack<>();
        while(!a.isEmpty()||!b.isEmpty()) {
            if(a.isEmpty()) temp.push(b.pop());
            else if(b.isEmpty()) temp.push(a.pop());
            else if(a.peek()<=b.peek()) temp.push(a.pop());
            else temp.push(b.pop());
        }
        while(!temp.isEmpty()) out.push(temp.pop());
        return out;
    }
    public static void main(String[] args){
        Stack<Integer>a=new Stack<>(),b=new Stack<>();
        int[] x={10,6,6,3,-2},y={8,6,4,0};
        for(int v:x)a.push(v);for(int v:y)b.push(v);
        System.out.println(mergeStacks(a,b));
    }
}
