public class Main {
    static class Node {int elem;Node next;Node(int x){elem=x;}}
    static void rangeReverse(Node dh,int start,int end) {
        if(dh.next==null||start<0||end<start)return;
        Node before=dh, cur=dh.next;
        for(int i=0;i<start&&cur!=null;i++){before=cur;cur=cur.next;}
        if(cur==null)return;
        Node segmentTail=cur, prev=null;
        for(int i=start;i<=end&&cur!=null;i++){
            Node nx=cur.next;
            cur.next=prev;
            prev=cur;
            cur=nx;
        }
        // Remove the selected segment from its old position.
        before.next=cur;
        Node outsideHead=dh.next;
        // Append the unchanged outside list after the reversed segment.
        segmentTail.next=outsideHead;
        dh.next=prev;
    }
    static Node list(int...v){Node d=new Node(0),t=d;for(int x:v){t.next=new Node(x);t=t.next;}return d;}
    static void print(Node d){for(Node p=d.next;p!=null;p=p.next)System.out.print(p.elem+" ");System.out.println();}
    public static void main(String[] args){Node d=list(3,5,8,7,2,1,6,4,2);rangeReverse(d,2,5);print(d);}
}
