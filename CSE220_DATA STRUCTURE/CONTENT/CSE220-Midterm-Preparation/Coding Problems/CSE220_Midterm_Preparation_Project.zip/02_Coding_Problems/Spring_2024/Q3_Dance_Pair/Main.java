import java.util.*;
public class Main {
    static void dancePair(Stack<String> st) {
        Queue<String> spareF=new ArrayDeque<>();
        String pending=null;
        while(!st.isEmpty()) {
            String cur=st.pop();
            if(pending==null) { pending=cur; continue; }
            char g1=pending.charAt(0), g2=cur.charAt(0);
            if(g1!=g2) { printPair(pending,cur); pending=null; }
            else {
                if(g1=='F') { spareF.offer(pending); pending=cur; }
                else {
                    if(!spareF.isEmpty()) printPair(spareF.poll(),pending);
                    pending=cur;
                }
            }
        }
        if(pending!=null && pending.charAt(0)=='F') spareF.offer(pending);
    }
    static void printPair(String a,String b) {
        if(a.charAt(0)=='M') System.out.println(a.substring(2)+" and "+b.substring(2)+" are paired");
        else System.out.println(b.substring(2)+" and "+a.substring(2)+" are paired");
    }
    public static void main(String[] args) {
        Stack<String> s=new Stack<>();
        String[] topToBottom={"M_10","F_20","F_4","F_5","M_3","M_19","M_1","M_7","F_9","F_18"};
        for(int i=topToBottom.length-1;i>=0;i--)s.push(topToBottom[i]);
        dancePair(s);
    }
}
