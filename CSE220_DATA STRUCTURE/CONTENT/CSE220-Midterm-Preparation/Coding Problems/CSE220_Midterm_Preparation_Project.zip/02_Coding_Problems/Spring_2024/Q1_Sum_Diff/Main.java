public class Main {
    static int[] sumDiff(int[][] a) {
        int rows=a.length, cols=a[0].length;
        int[] sums=new int[cols];
        for(int j=0;j<cols;j++)
            for(int i=0;i<rows;i++) sums[j]+=a[i][j];
        int[] out=new int[cols-1];
        for(int j=0;j<cols-1;j++) out[j]=sums[j+1]-sums[j];
        return out;
    }
    public static void main(String[] args) {
        int[][] a={{1,3,1},{6,4,2},{5,1,7},{9,3,3},{8,5,4}};
        int[] ans=sumDiff(a);
        for(int x:ans)System.out.print(x+" ");
    }
}
