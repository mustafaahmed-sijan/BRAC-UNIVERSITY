public class Main {
    static class Node { int elem; Node next; Node(int x){elem=x;} }
    static boolean isSumPossible(Node h,int target) {
        for(Node a=h;a!=null;a=a.next)
            for(Node b=a.next;b!=null;b=b.next)
                if(a.elem+b.elem==target) return true;
        return false;
    }
    static Node list(int... v){Node h=null,t=null;for(int x:v){Node n=new Node(x);if(h==null)h=n;else t.next=n;t=n;}return h;}
    public static void main(String[] args){System.out.println(isSumPossible(list(1,2,3,4,5),7));}
}
