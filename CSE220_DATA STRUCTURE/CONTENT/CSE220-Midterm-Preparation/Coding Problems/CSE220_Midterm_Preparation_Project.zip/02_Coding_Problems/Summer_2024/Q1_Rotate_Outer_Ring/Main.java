public class Main {
    static int[][] rotate(int[][] a) {
        int n=a.length;
        // Rotate each layer by n-1 positions along its perimeter.
        for(int layer=0;layer<1 && layer<n/2;layer++) {
            int last=n-1-layer;
            int length=4*(last-layer);
            for(int step=0;step<last-layer;step++) {
                int saved=a[layer][layer];
                for(int k=0;k<length-1;k++) {
                    int[] from=coordinate(layer,last,k+1);
                    int[] to=coordinate(layer,last,k);
                    a[to[0]][to[1]]=a[from[0]][from[1]];
                }
                int[] end=coordinate(layer,last,length-1);
                a[end[0]][end[1]]=saved;
            }
        }
        return a;
    }
    // Return the coordinate at clockwise perimeter offset k.
    static int[] coordinate(int first,int last,int k) {
        int side=last-first;
        if(k<=side) return new int[]{first,first+k};
        k-=side;
        if(k<=side) return new int[]{first+k,last};
        k-=side;
        if(k<=side) return new int[]{last,last-k};
        k-=side;
        return new int[]{last-k,first};
    }
    public static void main(String[] args) {
        int[][] a={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        rotate(a); for(int[] r:a){for(int x:r)System.out.print(x+" ");System.out.println();}
    }
}
