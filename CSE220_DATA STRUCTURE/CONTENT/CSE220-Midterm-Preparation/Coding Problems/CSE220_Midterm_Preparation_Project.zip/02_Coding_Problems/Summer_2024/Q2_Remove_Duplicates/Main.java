public class Main {
    static class Node {int elem;Node next;Node(int x){elem=x;}}
    static Node removeDuplicates(Node head) {
        for(Node cur=head;cur!=null;cur=cur.next) {
            Node prev=cur, scan=cur.next;
            while(scan!=null) {
                if(scan.elem==cur.elem) { prev.next=scan.next; scan=prev.next; }
                else { prev=scan; scan=scan.next; }
            }
        }
        return head;
    }
    static Node list(int... v){Node h=null,t=null;for(int x:v){Node n=new Node(x);if(h==null)h=n;else t.next=n;t=n;}return h;}
    public static void main(String[] args){Node h=removeDuplicates(list(101,103,101,102,103,104,105,105));while(h!=null){System.out.print(h.elem+" ");h=h.next;}}
}
