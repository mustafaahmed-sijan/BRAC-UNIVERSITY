import java.util.Stack;
public class Main {
    static Stack<Integer> adjacentSwap(Stack<Integer> s) {
        Stack<Integer> reversed=new Stack<>(), result=new Stack<>();
        boolean odd=s.size()%2==1;
        Integer savedTop=null;
        if(odd) savedTop=s.pop(); // The original top remains unchanged.
        while(!s.isEmpty()) reversed.push(s.pop());
        // reversed now exposes original bottom first; swapping pairs here
        // makes the final top-to-bottom order correct.
        while(!reversed.isEmpty()) {
            int first=reversed.pop();
            int second=reversed.pop();
            result.push(second);
            result.push(first);
        }
        if(odd) result.push(savedTop);
        return result;
    }
    public static void main(String[] args){Stack<Integer>s=new Stack<>();for(int i=1;i<=8;i++)s.push(i);System.out.println(adjacentSwap(s));}
}
