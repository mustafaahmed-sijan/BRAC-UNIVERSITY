public class Main {
    static class Node { int elem; Node next; Node(int x){elem=x;} }
    static boolean pairWiseEqual(Node a, Node b) {
        while(a!=null && b!=null) {
            if(a.next==null || b.next==null) return false;
            boolean same = (a.elem==b.elem && a.next.elem==b.next.elem)
                        || (a.elem==b.next.elem && a.next.elem==b.elem);
            if(!same) return false;
            a=a.next.next; b=b.next.next;
        }
        return a==null && b==null;
    }
    static Node list(int... v){ Node h=null,t=null; for(int x:v){Node n=new Node(x);if(h==null)h=n;else t.next=n;t=n;}return h;}
    public static void main(String[] args) {
        System.out.println(pairWiseEqual(list(10,15,34,41),list(15,10,34,41)));
    }
}
