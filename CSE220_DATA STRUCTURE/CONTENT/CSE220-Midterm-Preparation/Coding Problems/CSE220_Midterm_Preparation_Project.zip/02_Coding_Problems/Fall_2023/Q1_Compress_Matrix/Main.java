public class Main {
    static int[][] compressMatrix(int[][] a) {
        int r=a.length, c=a[0].length;
        int[][] out=new int[r/2][c/2];
        for(int i=0;i<r;i+=2) {
            for(int j=0;j<c;j+=2) {
                out[i/2][j/2]=a[i][j]+a[i+1][j]+a[i][j+1]+a[i+1][j+1];
            }
        }
        return out;
    }
    public static void main(String[] args) {
        int[][] a={{1,2,3,4},{5,6,7,8},{1,3,5,2},{-2,0,6,-3}};
        int[][] b=compressMatrix(a);
        for(int[] row:b) { for(int x:row) System.out.print(x+" "); System.out.println(); }
    }
}
