import java.util.Stack;
public class Main {
    static Stack<Integer> conditionalReverse(Stack<Integer> st) {
        Stack<Integer> out=new Stack<>();
        boolean first=true; int prev=0;
        while(!st.isEmpty()) {
            int x=st.pop();
            if(first || x!=prev) { out.push(x); prev=x; first=false; }
        }
        return out;
    }
    public static void main(String[] args) {
        Stack<Integer> s=new Stack<>();
        int[] bottomToTop={10,10,20,20,30,10,50};
        for(int x:bottomToTop)s.push(x);
        System.out.println(conditionalReverse(s));
    }
}
