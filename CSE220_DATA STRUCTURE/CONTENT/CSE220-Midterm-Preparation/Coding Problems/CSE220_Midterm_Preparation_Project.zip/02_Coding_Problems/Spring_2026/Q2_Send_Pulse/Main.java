public class Main {
    static class CellNode {
        int val,pulse_radius; CellNode next,prev;
        CellNode(int v,int r){val=v;pulse_radius=r;}
    }
    static CellNode sendPulse(CellNode head) {
        CellNode cur=head;
        while(cur!=null) {
            if(cur.pulse_radius<=0){cur=cur.next;continue;}
            int radius=cur.pulse_radius;
            CellNode left=cur,right=cur;
            for(int i=0;i<radius&&left.prev!=null;i++)left=left.prev;
            for(int i=0;i<radius&&right.next!=null;i++)right=right.next;
            CellNode after=right.next;
            CellNode before=left.prev;
            if(before==null) head=after; else before.next=after;
            if(after!=null) after.prev=before;
            cur=after; // Continue at first surviving node to the right.
        }
        return head;
    }
    static void print(CellNode h){while(h!=null){System.out.print("("+h.val+","+h.pulse_radius+") ");h=h.next;}}
    public static void main(String[] args){
        CellNode a=new CellNode(5,0),b=new CellNode(10,1),c=new CellNode(15,0),d=new CellNode(20,0);
        a.next=b;b.prev=a;b.next=c;c.prev=b;c.next=d;d.prev=c;
        print(sendPulse(a));
    }
}
