public class Main {
    static void decode(char[][] a) {
        int rows=a.length, cols=a[0].length;
        StringBuilder ans=new StringBuilder();
        for(int r=0;r<rows-1;r++) {
            for(int c=0;c<cols;c+=2) {
                int[][] pos={{r,c},{r+1,c+1},{r,c+1},{r+1,c}};
                for(int[] p:pos) {
                    int x=p[0],y=p[1];
                    if(y<cols && a[x][y]!='#') {ans.append(a[x][y]);a[x][y]='#';}
                }
            }
        }
        System.out.println(ans);
    }
    public static void main(String[] args) {
        char[][] a={{'T','R','A','V','E','R'},{'S','E','_','T','H','E'},{'_','G','R','I','D','!'}};
        decode(a);
    }
}
