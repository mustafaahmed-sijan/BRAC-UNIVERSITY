import java.util.*;
public class Main {
    static Queue<Integer> queueGroupReverse(Queue<Integer> q,int k) {
        if(k<=1)return q;
        int n=q.size();
        Queue<Integer> result=new ArrayDeque<>();
        Stack<Integer> st=new Stack<>();
        int full=n/k, rem=n%k;
        for(int g=0;g<full;g++) {
            for(int i=0;i<k;i++) st.push(q.remove());
            while(!st.isEmpty()) result.add(st.pop());
        }
        // The final incomplete group stays in its original order.
        while(!q.isEmpty()) result.add(q.remove());
        return result;
    }
    public static void main(String[] args){
        Queue<Integer> q=new ArrayDeque<>();for(int i=1;i<=8;i++)q.add(i);
        System.out.println(queueGroupReverse(q,3));
    }
}
