public class Main {
    static class Node { int elem; Node next; Node(int x){elem=x;} }
    static Node reverseAndSwap(Node head,int i) {
        Node suffix=head;
        for(int k=0;k<=i;k++) suffix=suffix.next;
        Node prev=null,cur=head;
        for(int k=0;k<=i;k++) { Node nx=cur.next; cur.next=prev; prev=cur; cur=nx; }
        Node reversedHead=prev, reversedTail=head;
        reversedTail.next=null;
        if(suffix==null) return reversedHead;
        Node t=suffix; while(t.next!=null)t=t.next;
        t.next=reversedHead;
        return suffix;
    }
    static Node list(int... v){Node h=null,t=null;for(int x:v){Node n=new Node(x);if(h==null)h=n;else t.next=n;t=n;}return h;}
    static void print(Node h){while(h!=null){System.out.print(h.elem+" ");h=h.next;}System.out.println();}
    public static void main(String[] args){print(reverseAndSwap(list(5,7,6,3,8,2,1),3));}
}
