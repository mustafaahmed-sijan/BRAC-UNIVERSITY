public class Main {
    static void zigZag(int[][] a) {
        int n=a.length;
        for(int s=0;s<=2*n-2;s++) {
            if(s%2==0) {
                int r=Math.min(s,n-1), c=s-r;
                while(r>=0 && c<n) { System.out.print(a[r][c]+" "); r--; c++; }
            } else {
                int c=Math.min(s,n-1), r=s-c;
                while(c>=0 && r<n) { System.out.print(a[r][c]+" "); r++; c--; }
            }
        }
        System.out.println();
    }
    public static void main(String[] args) {
        int[][] a={{1,2,3},{4,5,6},{7,8,9}};
        zigZag(a);
    }
}
