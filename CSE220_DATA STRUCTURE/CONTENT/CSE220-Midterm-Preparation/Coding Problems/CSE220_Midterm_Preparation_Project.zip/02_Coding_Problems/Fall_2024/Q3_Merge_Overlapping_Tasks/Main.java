import java.util.*;
public class Main {
    static void printTotalTask(int[][] tasks) {
        Stack<int[]> merged=new Stack<>();
        for(int[] task:tasks) {
            if(merged.isEmpty() || task[0]>=merged.peek()[1]) merged.push(new int[]{task[0],task[1]});
            else merged.peek()[1]=Math.max(merged.peek()[1],task[1]);
        }
        Stack<int[]> reverse=new Stack<>();
        while(!merged.isEmpty()) reverse.push(merged.pop());
        while(!reverse.isEmpty()) {int[] x=reverse.pop();System.out.println(x[0]+", "+x[1]);}
    }
    public static void main(String[] args) {
        int[][] t={{1,5},{2,3},{4,6},{7,10},{9,11},{12,15}};
        printTotalTask(t);
    }
}
