import java.util.Stack;
public class Main {
    static Stack<Integer> depositSum(Stack<Integer> st, int window) {
        Stack<Integer> sums = new Stack<>();
        while (!st.isEmpty()) {
            int sum = 0, count = 0;
            while (count < window && !st.isEmpty()) {
                int x = st.pop();
                if (x > 0) sum += x;
                count++;
            }
            sums.push(sum);
        }
        // Reverse twice so the most recent window sum becomes the top.
        Stack<Integer> temp = new Stack<>();
        while (!sums.isEmpty()) temp.push(sums.pop());
        while (!temp.isEmpty()) st.push(temp.pop());
        return st; // Same stack object is returned.
    }
    public static void main(String[] args) {
        Stack<Integer> s = new Stack<>();
        int[] topToBottom={12,-3,8,15,-7,-20,-6,-2,9,14};
        for(int i=topToBottom.length-1;i>=0;i--) s.push(topToBottom[i]);
        depositSum(s,4);
        System.out.println("Top to bottom: " + s);
    }
}
