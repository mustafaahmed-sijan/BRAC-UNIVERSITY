public class Main {
    static class Node {
        int key; String val; Node next;
        Node(int k, String v) { key=k; val=v; }
    }
    static Node[] ht = new Node[5];
    static int hash(int key) { return key % ht.length; }

    static void insert(int key, String value) {
        int idx = hash(key);
        Node cur = ht[idx], prev = null;
        while (cur != null && cur.key < key) {
            prev = cur; cur = cur.next;
        }
        if (cur != null && cur.key == key) { // Replace duplicate key.
            cur.val = value;
            return;
        }
        Node n = new Node(key, value);
        n.next = cur;
        if (prev == null) ht[idx] = n;
        else prev.next = n;
    }
    static void printTable() {
        for (int i=0;i<ht.length;i++) {
            System.out.print(i+": ");
            for (Node p=ht[i];p!=null;p=p.next)
                System.out.print("("+p.key+","+p.val+") ");
            System.out.println();
        }
    }
    public static void main(String[] args) {
        insert(2,"DOG"); insert(9,"CROW"); insert(8,"GOAT");
        printTable();
    }
}
