public class Main {
    static void localMinima(int[][] a, int threshold) {
        int r = a.length, c = a[0].length;
        // Reverse scan guarantees bottom-rightmost valid answer.
        for (int i = r - 1; i >= 0; i--) {
            for (int j = c - 1; j >= 0; j--) {
                if (a[i][j] > threshold) continue;
                boolean ok = true;
                int[] dr = {-1, 1, 0, 0};
                int[] dc = {0, 0, -1, 1};
                for (int k = 0; k < 4; k++) {
                    int x = i + dr[k], y = j + dc[k];
                    if (x >= 0 && x < r && y >= 0 && y < c && a[x][y] <= threshold) {
                        if (a[i][j] >= a[x][y]) ok = false;
                    }
                }
                if (ok) {
                    System.out.println("Local minimum at (" + i + ", " + j + ") = " + a[i][j]);
                    return;
                }
            }
        }
        System.out.println("No valid local minimum");
    }
    public static void main(String[] args) {
        int[][] a={{22,21,1000,23},{25,17,21,1000},{1000,19,18,22},{21,22,1000,20}};
        localMinima(a,100);
    }
}
