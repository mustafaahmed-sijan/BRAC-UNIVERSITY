# Extracted source text from all uploaded papers

This appendix preserves the readable text extracted from each of the 8 source PDFs. Page breaks are marked. Image-only diagrams may not be represented in extracted text.



# CSE220 Midterm Summer-25 Set-A.pdf

```text
--- PAGE 1 ---
BRAC UNIVERSITY 
Department of Computer Science and Engineering 
Examination: Mid-Term 
Duration: 75 Minutes 
Number of Questions: 4 
CSE220: Data Structures 
Summer 2025 
Full Marks: 30 
  No. of Pages: 3 
 
●​ Answer all 4 questions. No washroom breaks. 
●​ At the end of the exam, put the question paper inside the answer script and return both. 
 
Question 1: CO1 [8 Points] 
You're working as a terrain analyst for a Mars exploration rover. The rover receives a grid 
(matrix) of terrain height values scanned from orbit. However, due to occasional solar 
interference, some readings show spikes (noisy values) that are unrealistically high and should 
be ignored. 
Your task is to complete the following function/method to help the rover find a local 
minimum — a position where the height is lower than its adjacent neighbors (top, bottom, left, 
right), excluding any cells where the height is above a certain noise threshold. 
To help guide the rover better, if multiple valid local minima exist, choose the last one from 
the bottom right of the matrix. 
A local minimum is a cell strictly less than its up, down, left, and right neighbors (4 directions). 
Ignore any cell or neighbor that is above the given noise threshold. 
 
Input Array 
Returned Array 
Explanation 
matrix = [ 
[  22, 21, 1000,   23], 
[  25, 17,   21, 1000], 
[1000, 19,   18,   22], 
[  21, 22, 1000,   20] 
] 
noise_threshold = 100 
 
Local minimum found 
at: (2, 2)  
● (2, 2) has value 18. 
● Its neighbors: 21 (up), 1000 (down, 
ignored), 19 (left), 22 (right). 
● 18 is less than all valid neighbors and 
the bottom rightmost item 
 
Python Notation 
Java Notation 
def localMinima(matrix, threshold): 
    # To DO 
 
public static void localMinima 
         (int[][] matrix, int threshold){ 
      //To DO 
} 
 
 
Question 2: CO5 [8 Points] 
 
You are asked to implement part of a Hashtable class where the keys are integers and the 
values are strings. The class has an array of Node type named ht, which is considered the 
hashtable. You have to write the class method insert, which should insert a new key-value pair 
in the hashtable.  
                                                               Page 1 of 3                                                            Set-A 
Name: 
 
(Please write in CAPITAL LETTERS) 
ID: 
Section:  


--- PAGE 2 ---
The class method hash(key) method computes the hash index based on the key and returns 
the index of the hashtable. This method is already written for you. You shall use this while 
inserting a key-value pair.  
While inserting, if there's any collision, you should follow the separate chaining approach; 
however, you should make sure that the nodes are added in ascending order of the keys. If 
there's any duplicate key, replace the previous value of that corresponding key. 
Make sure that the time complexity of your code is O(n) 
The Node class (non-dummy-headed singly type) for the hashtable is already implemented with 
key (int), val (String), and next (Node) variables. You do not need to write it. 
Initial Hashtable ht 
After executing insert(8,"GOAT") 
 
Index 0: (3, CAT) -> (4, EELS) 
Index 1: (5, LION) 
Index 2: (2, DOG) -> (9, CROW) 
Index 3: (27, WOLF) 
Index 4: (10, FISH) -> (11, OWL) 
Assume 8 is mapped at index 2. 
Index 0: (3, CAT) -> (4, EELS) 
Index 1: (5, LION) 
Index 2: (2, DOG) -> (8, GOAT) -> (9, CROW) 
Index 3: (27, WOLF) 
Index 4: (10, FISH) -> (11, OWL) 
Use the variable named “ht” to access the hashtable inside the method insert. 
# Python notation 
 
def hash(key): 
        # use this function 
        # already written 
 
def  insert(key, value): 
        # Write your code here 
 
 
// Java notation 
 
int hash(int key){ 
        // use this function 
        // already written 
} 
void insert(int key, String value){ 
        // Write your code here 
} 
 
Question 3: CO3 [8 Points] 
Suppose you are developing a personal banking app that tracks daily account activity. Each 
transaction recorded in the app represents either a deposit (a positive integer) or a withdrawal 
(a negative integer). These transactions are stored in a Stack, with the most recent transaction 
on top. 
You need to implement a function named depositSum() that takes two arguments: a stack of 
transaction data and an integer representing the window size. The function should compute the 
sum of only the deposit values within each consecutive window of the given size and return 
the modified stack containing these summed values. If the last window contains fewer elements 
than the specified window size, it should still be processed using the remaining values. The 
most recent window's sum should appear at the top of the returned stack. 
 
The Stack class is implemented for you. Its public instance methods are push(), pop(), 
peek(), and isEmpty(). The isEmpty() method returns a boolean indicating whether the stack is 
empty. The peek() and pop() methods return null or None if the stack is empty (i.e., underflow 
condition). All other members of the Stack class are private and should not be accessed directly. 
You can only use the public instance methods provided. No need to consider the overflow 
exception for the Stack class. 
 
 
 
                                                               Page 2 of 3                                                            Set-A 


--- PAGE 3 ---
 
You cannot use any data structure other than the stack. You can create instances of the 
stack as many times as you want. 
 
Stack Creation Example 
Python 
Java 
stack = Stack() 
Stack stack = new Stack() 
 
Input Stack 
Modified Stack 
Explanation 
stack =  
Top ➔ 
12 
 
-3 
 
8 
 
15 
 
-7 
 
-20 
 
-6 
 
-2 
 
9 
 
14 
 
window = 4 
stack =  
Top ➔ 
35 
 
0 
 
23 
 
Since the window size is given as 4, each window will 
have 4 values (except possibly the last one, if there are 
fewer remaining elements). 
 
Window 1: has [12, -3, 8, 15] 
Sum of deposits: 12 + 8 + 15 = 35 
 
Window 2: has [-7, -20, -6, -2] 
Sum of deposits: 0  
(Sum is 0 since no deposits in this window) 
 
Window 3: has [9, 14] (remaining 2 elements) 
Sum of deposits: 9 + 14 = 23 
 
Modified stack means you must return the stack you 
received via the function parameter. 
 
Python 
Java 
def depositSum(st, window): 
        # To Do 
public static Stack depositSum(Stack st, int window){ 
        // To Do  
} 
 
Question 4: CO2 [2 + 2 + 2 Points] 
(Write the correct answers in the answer script.) 
I.​
Given a 3D array index [1][2][3] from an array with dimensions 2×3×4, determine 
whether there exists a corresponding valid 2D array index [i][j] in a 2D array of 
dimensions 5×3 that maps to the same linear index. If such a 2D index exists, provide it. 
If not, explain why it is invalid. 
II.​
In case of memory consumption, which one do you think performs better between a 
linked list and a hashtable using forward chaining as collision handling? Briefly justify 
your answer in terms of space complexity. 
III.​
If the top pointer of the stack pointed to the first inserted element instead of the last 
inserted one, what would be the time complexity of the stack operations pop and peek in 
a linked list-based implementation? Explain.​
 
                                                               Page 3 of 3                                                            Set-A 

```



# bracu.cse220 - midTerm - fa23 A.pdf

```text
--- PAGE 1 ---
Page 1 of 2 
 
BRAC UNIVERSITY 
Department of Computer Science and Engineering 
Examination: Midterm 
Duration: 80 Minutes 
No. of Questions: 3 
CSE 220: Data Structures 
Semester: Fall 2023 
Full Marks: 30 
No. of Pages: 2 
 
 
Name: 
(Please write in CAPITAL LETTERS) 
ID: 
Section: 
✔ Use the back part of the answer script for rough work. No washroom breaks. 
✔ At the end of the exam, put the question paper inside the answer script and return both. 
✔ Understanding questions is part of exam. 
 
Question 1: CO1, CO5 [2 + 8 Points] 
I. 
Suppose you are given a multi-dimensional array with dimension 5x5x3. What is the multidimensional 
index for the linear index 65? 
II. 
Complete the function compress_matrix that takes a 2D array as a parameter and return a new 
compressed 2D array. In the given array the number of rows and columns will always be even. 
Compressing a matrix means grouping elements in 2x2 blocks and sums the elements within 
each block. Check the sample input output for further clarification.  
         Hint: Generally the block consists of the (i,j), (i+1,j), (i,j+1) and (i+1, j+1) elements for 2x2 
blocks. 
You cannot use any built-in function except len() and range(). You can use the np variable 
to create an array. 
Python Notation 
Java Notation 
import numpy as np 
def compress_matrix (mat): 
# To Do 
public int[ ][ ] compress_matrix (int[] [] mat) { 
// To Do 
} 
 
Sample Input 
array 
All Box (No need to 
create these arrays) 
Returned 
Array 
Explanation 
[ 
[1, 2, 3, 4], 
[5, 6, 7, 8], 
[1, 3, 5, 2], 
[-2, 0, 6,-3] 
] 
 
[[1, 2],          [[3, 4], 
 [5, 6]]          [[7, 8]] 
  
 [[1, 3],          [[5, 2], 
 [-2, 0]]          [[6, -3]] 
 
[[14, 22], 
 [ 2, 10]] 
[[1+2+5+6,      3+4+7+8], 
 [1+3+-2+0,     5+2+6+-3]] 
 
Question 2: CO3 [2 + 8 Points] 
I. 
Write down two disadvantages of Linked List over Array. 
II. 
You are given two linked lists of the same even length. Your task is to complete a 
method pairwiseEqual() that takes two singly linear linked list heads as arguments, 
checks if the linked lists are equal pairwise and returns True/False. 
Two linked lists will be equal pairwise if the node values of every pair in Linked List 1 
are equal to the node values of corresponding pair in Linked List 2 irrespective of their 
sequence [i.e. the sequence does not matter]. 
 
[DO NOT USE OTHER DATA STRUCTURE OTHER THAN GIVEN LINKED LISTS] 
 
 
A 


--- PAGE 2 ---
Page 2 of 2 
 
Sample Input 
Returned Value 
Explanation 
head1 =10-->15-->34-->41 
 head2 = 15-->10-->34-->41  
True 
Linked List 1 Pairs: (10,15) ,(34,41) ; 
Linked List 2 Pairs: (15,10) , (34,41) 
head1 =10-->15-->34-->42 
 head2 = 15-->10-->34-->41  
False 
Linked List 1 Pairs: (10,15) ,(34,42) ; 
Linked List 2 Pairs: (15,10) , (34,41) 
 
Python Notation 
Java Notation 
def pairWiseEqual(h1, h2): 
           # To Do 
public boolean pairWiseEqual(Node h1, Node h2) { 
// To Do 
} 
Question 3: CO1, CO5 [5 + 5 Points] 
 
I. 
You are given a dummy headed doubly circular linked list and a block of code. The 
list is like below: 
 
     
 
 
 
 
 
Draw the resulting list (The list you will find after the nested loop) for each value i in your 
answer script. Mention the value of i and the resulting list, no need to show the intermediate 
states. 
 
II. 
Consider that a MidStack class has been created containing the push(element), pop(), peek() and 
isEmpty() functions. No need to implement MidStack class.  The MidStack class implements a 
singly linked list-based Stack hence overflow is not possible. The pop() and peek() functions 
return None in case of the underflow. 
 
Complete the function conditional_reverse which will take an object of MidStack that contains 
some integer values. The function returns a new stack which will contain the values in reverse 
order from given stack with the exception that if consecutive numbers are the same, it picks only 
one from them. You cannot use any other data structure except MidStack. 
Remember that a stack has no other functions than push, pop, peek, and isEmpty 
Python Notation 
Java Notation 
def conditional_reverse(stack): 
                                      # To Do 
public MidStack conditional_reverse(MidStack stack) { 
// To Do 
} 
 
Sample Input Stack (Right most 
is the top) 
Returned Stack (Right 
most is the top) 
Explanation 
Stack: 10, 10, 20, 20, 30, 10, 50 
Top = 50 
Stack: 50, 10, 30, 20, 10 
Top = 10 
Consecutive 20 and 10 are not 
present in the output reversed 
stack 
 
for i in range(5): 
        for j in range(i): 
            n1 = dh.next 
            n2 = n1.next 
            n3 = dh.prev 
            dh.next = n2 
            n2.prev = dh 
            n3.next = n1 
            n1.next = dh 
            n1.prev = n3 
            dh.prev = n1 

```



# bracu.cse220 - midTerm - sp24 A.pdf

```text
--- PAGE 1 ---
BRAC UNIVERSITY
Department of Computer Science and Engineering
Examination: Mid-Term
Duration: 80 Minutes
Number of Questions: 3
CSE220: Data Structures
Semester: Spring 2024
Full Marks: 30
No. of Pages: 3
✔Answer all 3 questions. No washroom breaks.
✔At the end of the exam, put the question paper inside the answer script and return both.
Question 1: CO1 [2 + 8 Points]
I.
Suppose you are given a multi-dimensional array with dimensions 4x5x4. What is the
linear index of the multidimensional index [2][1][0]?
II.
Suppose you're working as a cryptographer for a secret intelligence agency. You are
given an encrypted matrix as an input. You have to decrypt it after some processing of
this matrix.
To decrypt this message efficiently, you have a task to construct a method called
sum_diff(matrix) which takes an encrypted matrix as input and returns a decrypted
linear array. The process of finding the decrypted linear array is given below:
You have to find out the column-wise summations for each column and store the
difference of subsequent column-wise summations in a new linear array.
Sample Input
Sample output
Explanation
1
3
1
6
4
2
5
1
7
9
3
3
8
5
4
-13
1
Sum of 0th column = 29
Sum of 1st column = 16
Sum of 2nd column = 17
Therefore, the size of the
resulting array is 2 and the
array is:
16-29 = -13
17-16 = 1
Python Notation
Java Notation
def sum_diff(matrix):
# To Do
public int[] sum_diff(matrix) {
// To Do
}
Question 2: CO5 [10 Points]
You are given a non-dummy headed singly linear linked list containing positive integers. Your
task is to complete the given method IsSumPossible() which takes the head of the linked list
and an integer, n as input. If the integer n can be obtained by summing any two of the elements
of the linked list, return True, else return False.
Page 1 of 3
Set-A
Name:
(Please write in CAPITAL LETTERS)
ID:
Section:


--- PAGE 2 ---
Hint: There might be more than one such pair possible, you don’t have to check all such
pairs.
[DO NOT USE OTHER DATA STRUCTURE OTHER THAN GIVEN LINKED LIST]
Sample Input
Returned Value
Explanation
list = 1→2→3→4→5
n = 7
True
Sum of the elements (3,4) or (2,5) equals
7
list = 1→2→4→5→6
n = 4
False
There are no two elements that make the
sum 4. Note that though there is an
element 4 itself in the list, the output will
be False.
list = 5
n = 5
False
There is only one element so, the sum of
two elements cannot be 5
Python Notation
Java Notation
def IsSumPossible(head, n):
# To Do
public boolean IsSumPossible(Node head, int n) {
// To Do
}
Question 3: CO3 [2+8 Points]
I.
Suppose that an intermixed sequence of stack push and pop operations are performed.
The pushes push the integers 0 through 9 in order; the pops print out the return value.
Which of the following sequences could not occur for push and pop operation? Write all
the correct answers.
A. 1 2 3 4 5 6 9 8 7 0
B. 0 4 6 5 3 8 1 7 2 9
C. 1 4 7 9 8 6 5 3 0 2
D. 2 1 4 3 6 5 8 7 9 0
II.
You are given a Stack of people. They should be paired off as man with woman, woman
with man. If a male and a female are consecutive in the stack, they get paired
immediately. If there are consecutive females found without any subsequent males, then
the spare females should be saved in a Queue for future pairing. If there are consecutive
males found without any subsequent females, we try to pair a male with the first spare
female [if available] from the Queue. If no spare female is available, then the male is
discarded. The same logic applies to consecutive females without any subsequent
males.
The stack class and the Queue class are implemented for you. The public instance
methods in the Stack class are push(), pop(), peek(), and isEmpty(). The public
instance methods in the Queue class are enq(), deq(), peek(), and isEmpty(). In
both classes, isEmpty() returns a boolean value, peek() and pop() returns None for
underflow. All other members of both classes are private. You can only use the public
instance methods. No need to consider the overflow exception for both Stack and Queue
classes.
Your task is to complete the given method dance_pair() that takes a stack and prints
every male-female pair.
Page 2 of 3
Set-A


--- PAGE 3 ---
Every male and female are written in this way - M_id or F_id. A method called
id_gender_extractor(s)
is implemented for you that returns the id and gender from a
string,s.
You do not need to write the methods/classes that are implemented for you. You
cannot use any data structure other than stack and queue.
Sample Input
Output
Explanation
st =
M_10
F_20
F_4
F_5
M_3
M_19
M_1
M_7
F_9
F_18
10 and 20 are paired
together
5 and 3 are paired
together
4 and 19 are paired
together
7 and 9 are paired
together
M_10 and F_20, F_5 and
M_3,
M_7 and F_9 are
sequential
in
the
stack.
They are paired up.
From
F_4,
there
are
consecutive
females. So,
F_4 is stored in the queue
for future pairing.
From
M_19,
there
are
consecutive males. M_19
is paired with spare F_4.
M_1
is
discarded
since
there is no spare female
with whom M_1 can be
paired.
Given:
def id_gender_extractor(s):
if s != None:
return s[0],s[2:] #gender, id
else:
return None, None
Driver Code:
st = Stack()
st.push('F_18')
st.push('F_9')
st.push('M_7')
st.push('M_1')
st.push('M_19')
st.push('M_3')
st.push('F_5')
st.push('F_4')
st.push('F_20')
st.push('M_10')
dance_pair(st)
Python Notation
Java Notation
def dance_pair(st):
# To Do
public void dance_pair(Stack st) {
# To Do
}
Page 3 of 3
Set-A

```



# CSE220 Midtem Fall-25 Set-A.pdf

```text
--- PAGE 1 ---
 
 
BRAC UNIVERSITY 
Department of Computer Science and Engineering 
Examination: Midterm 
Duration: 80 Minutes 
No. of Questions: 4 
CSE 220: Data Structures 
Semester: Fall 2025 
Full Marks: 30 
No. of Pages: 3 
 
 
Name: 
ID: 
Section: 
✔ Use the back part of the answer script for rough work. No washroom breaks. 
✔ At the end of the exam, put the question paper inside the answer script and return both. 
✔ Understanding questions is part of the exam. 
 
Question 1: CO5 [8 Points] 
You are exploring an energy grid matrix using a direction map matrix, both of which are of an m x n shape. 
●​ grid[x][y] – contains integer energy values where x , y are the indices. 
●​ directions[x][y] – contains String direction symbols: "NE", "NW", "SE", "SW". 
Each cell of the directions matrix tells you in which direction the energy comes to that specific coordinate of the 
grid matrix. Meaning, for the sample example below the (0,1) cell is getting energy from all the cells which are 
“South East” of itself where the values are 7,12. So, the (0,1) cell's energy is 2+7+12=21. 
Your task is to compute how much total energy each block absorbs by following the 
direction shown on the direction map. So, write a function/method blockEnergySum() 
that computes a new Energy Matrix where: 
●​ For each cell in the grid matrix, start from its own position. 
●​ Look at its direction symbol (i.e “SE” for [0,1]) in the directions matrix. Keep 
moving in that diagonal direction in the grid matrix until you exit the grid. 
●​ While moving, you sum up all visited cell values, including the starting cell of each 
cell. 
●​ Do this for all the cells of the grid matrix. Lastly, return the newly computed 
Energy Matrix where each of the cells contain the energy summations of each respective cell of the grid 
matrix. 
Note: The space complexity of your solution must not exceed O(m*n). 
Given Matrices 
Returned Energy Matrix  
grid = 
 
directions =  
 
34 
21 
18 
4 
5 
15 
11 
8 
9 
23 
19 
21 
13 
23 
15 
16 
 
1 
2 
3 
4 
 
“SE” 
“SE” 
“SW” 
“NE” 
5 
6 
7 
8 
 
“SW” 
“SW” 
“NE” 
“SE” 
9 
10 
11 
12 
 
“NW” 
“SW” 
“NE” 
“NW” 
13 
14 
15 
16 
 
“SE” 
“NW” 
“SW” 
“NE” 
 
Explanation 
[0,0]⇒ SE: includes its own value 1 then SE path adds 6,11,16 ⇒ 1+(6+11+16) = 34 
[0,1]⇒ SE: includes its own value 2 then SE path adds 7,12 ⇒ 2+(7+12) = 21 
[0,2]⇒ SW: includes its own value 3 then SW path adds 6,9 ⇒ 3+(6+9) = 18 
[0,3]⇒ NE: includes its own value 4 but moving NE immediately exits the grid, so no additional cells 
are 
   added ⇒ total energy = 4 which is shown in the corresponding index of returned Energy Matrix. 
[1,0]⇒ SW: same as [0,3] since the “SW” direction also exits the grid ⇒ total energy = 5. 
[1,1]⇒ SW: includes its own value 6, then SW path adds 9 ⇒ 6+(9) = 15. 
Other cells follow the same process: summing the cell's own value & cells along its diagonal direction. 
Java Method Signature 
Python Function Signature 
static int[][] blockEnergySum( int[][] grid, String[][] directions ){ 
def blockEnergySum( grid , directions ) 
 


--- PAGE 2 ---
 
//TODO 
} 
#TODO 
 
Question 2: CO1 [8 Points] 
 
Write a function/method named rangeReverse() that takes the head of a dummy-headed singly linked list and two 
integers as parameters. The two integers represent a starting index and an ending index. 
You need to reverse the nodes within the given range. Furthermore, the nodes that lie outside the given range must 
remain in their original order and be appended after the reversed segment. Please note that this is an in-place 
operation meaning you cannot create any new nodes. 
No need to write Node class. Assume, the Node class is already defined and contains: int elem and Node next. 
You cannot create any new nodes to solve this task. 
Given Linked List 
Modified Linked List 
Explanation 
[DH]⇒3⇒5⇒8⇒7⇒2⇒1⇒6⇒4⇒
2 
start = 2, end = 5 
[DH]⇒1⇒2⇒7⇒8⇒3⇒5⇒6⇒4
⇒2 
Nodes from indices 2 to 5 were 
reversed and moved to the start. All 
other nodes remained in place and 
were appended after the reversed 
part. 
[DH]⇒3⇒5⇒8⇒7⇒2⇒1⇒6⇒4⇒
5 
start = 4, end = 12 
[DH]⇒5⇒4⇒6⇒1⇒2⇒3⇒5⇒8
⇒7 
Nodes from indices 4 to 8 were 
reversed and moved to the start. All 
other nodes remained in place and 
were appended afterward. The end 
index 12 was ignored as it was 
outside the valid range. 
Java Method Signature 
Python Function Signature 
static void rangeReverse( Node dHead, int start, int end ){ 
   // TODO 
} 
def rangeReverse( dHead, start, end ) 
#TODO 
 
Question 3: CO1 [6 Points] 
 
You are given two stacks, each sorted in non-decreasing order from top to bottom. Your task is to implement a 
function named mergeStacks() that merges the two stacks into a single stack and finally returns the merged stack. 
The merged stack also must be in non-decreasing order. 
No need to write the Stack class. Assume, a linked list based stack is already implemented for you. Its public 
instance methods are push(), pop(), peek(), and isEmpty(). The instance variables of this class are private. 
 
You cannot use any data structure other than the stack. You can create as many stacks as you want. 
Given Stacks 
Returned Stack 
Explanation 
stack1 = -2 3 6 6 10 
stack2 = 0 4 6 8 
stack = -2 0 3 4 6 6 6 8 10 
Both 
stack1 
and 
stack2 
are 
in 
non-decreasing order. They are merged 
into a stack, and the merged stack is 
also in non-decreasing order. 
Here, the leftmost value is the top 
 
Java Stack Creation 
Python Stack Creation 
Stack stk = new Stack(); 
stk = Stack() 
Java Method Signature 
Python Method Signature 
static Stack mergeStacks(Stack stack1, Stack stack2) { 
    // TODO 
} 
def mergeStacks(stack1, stack2): 
    # TODO 
 
 


--- PAGE 3 ---
 
 
Question 4: CO3 [8 Points] 
Answer the questions in your Answer Script 
 
i.​
Suppose you are given a multi-dimensional array with dimensions 6x4x8.  
What is the linear index of [4][2][5] multidimensional index? ​
​
​
​
​
[2 points] 
 
ii.​
In a linked list based queue, what is the time complexity of getting the first inserted element?​​
[1 point] 
a.​ O(1) 
b.​ O(n) 
c.​ O(log(n)) 
d.​ O(n2) 
 
iii.​
In a NxN 2D array, what will be the time complexity if we want to calculate the sum of the elements of the left 
diagonal in the most efficient way? ​​
​
​
​
​
​
​
​
[1 point] 
a.​ O(log(n)) 
b.​ O(2n) 
c.​ O(n) 
d.​ O(n2) 
 
iv.​
For the hash table shown on the right, what can be a possible sequence in 
which the key value pairs are inserted? Here, the integer values are keys. 
Collision is resolved by appending a new item at the end. 
[Hash Function = key%hash table length] ​ ​
​
[2 points] 
a.​ (8, D), (12, A), (9, B), (6, M), (14, N) 
b.​ (12, A), (6, M), (14, N), (8, D), (9, B) 
c.​ (14, N), (9, B), (6, M), (8, D), (12, A) 
d.​ (14, N), (9, B), (6, M), (12, A), (8, D) 
 
v.​
Your two friends suggest the following hash functions to map integer keys into a hash table of length n: 
➢​ friend 1’s hash function = key*2 % n 
➢​ friend 2’s hash function = key % (n/2) 
Being a student who learned HashTable data structure, evaluate the 2 functions and find out: 
a.​ What is the potential problem (if any) with Friend 1’s hash function?​
​
​
​
[1 point] 
b.​ What is the potential problem (if any) with Friend 2’s hash function?​
​
​
​
[1 point] 
Provide a one-line answer for each of the two questions above. 
 
 

```



# CSE220 Midtem Spring-26 Set-A.pdf

```text
--- PAGE 1 ---
​BRAC UNIVERSITY​
​Department of Computer Science and Engineering​
​Examination​: Midterm​
​Duration​: 80 Minutes​
​No. of Questions​: 4​
​CSE 220: Data Structures​
​Semester​: Spring 2026​
​Full Marks​: 30​
​No. of Pages​: 3​
​Name:​
​ID:​
​Section:​
​✔​​Use the back​​part​​of the answer script for rough​​work.​​No washroom breaks.​
​✔​​At the end of the exam, put the question​​paper​​inside​​the answer script and​​return both​.​
​✔​​Understanding questions is part of the exam.​
​[You’re not allowed to use any extra data structures to solve Question 1 & 2]​
​Question 1: CO5 [6 Points]​
​The​​hidden​​message​​was​​encrypted​​by​​placing​​characters​​in​​a​​2D​​matrix,​​and​​it​​can​​only​​be​​recovered​​if​
​the​​matrix​​is​​traversed​​in​​a​​specific​​order.​​Your​​task​​is​​to​​write​​a​​method​​decode()​​that​​takes​​the​​matrix​​in​
​its​ ​parameter​ ​and​ ​follows​ ​the​ ​given​ ​traversal​ ​sequence​ ​to​ ​print​ ​the​ ​decoded​ ​message.​ ​Assume,​ ​the​
​column length of the matrix is always even.​
​Sample Given Matrix​
​Sample Output​
​Hint:​​Imagine a 2x2 block traversing the 2D​
​matrix row-wise. To keep track of visited/printed​
​index, after printing assign ‘#’ in that particular​
​index so that it is not printed the second time.​
​TRAVERSE_THE_GRID!​
​Explanation​
​The sequence in which the grid is to be traversed​
​(0,0) (1,1) (0,1) (1,0) → TRAV​
​(0,2) (1,3) (0,3) (1,2) → ERSE​
​(0,4) (1,5) (0,5) (1,4) → _THE​
​(1,0) (2,1) (1,1) (2,0) → _G​
​(since (1,0)&(1,1) were printed earlier, it was not​
​printed the second time, so any index/co-ordinate​
​visiting the 2nd time will not be printed)​
​(1,2) (2,3) (1,3) (2,2) → RI​
​(1,4) (2,5) (1,5) (2,4) → D!​
​Python Method Signature​
​Java Method Signature​
​def decode( matrix ):​
​public static void decode(char[][] matrix)​
​Question 2: CO1 [8 Points]​
​Assume​​a​​custom​​Non-Dummy​​headed​​linear​​Doubly​​Linked​​List​​has​​been​​implemented​​using​​a​​class​
​called​ ​CellNode​.​ ​Each​ ​node​ ​contains​ ​an​ ​integer​ ​val​ ​and​ ​an​ ​integer​ ​pulse_radius​.​ ​A​ ​pulse_radius​
​greater​​than​​zero​​indicates​​that​​the​​node​​emits​​a​​pulse.​​Pulses​​occur​​one​​after​​another​​from​​left​​to​​right.​
​When​​a​​node​​emits​​a​​pulse,​​it​​destroys​​itself,​​a​​number​​of​​nodes​​to​​its​​immediate​​left​​and​​right​​equal​​to​​its​
​pulse_radius​. Remaining nodes "snap" together, re-linking​​to maintain the list structure.​
​If​ ​a​ ​node​ ​containing​ ​a​ ​pulse​ ​is​ ​destroyed​ ​by​ ​a​ ​previous​ ​pulse,​ ​it​ ​is​ ​gone​ ​and​ ​cannot​ ​emit​ ​a​ ​pulse​
​separately​​and​​does​​not​​affect​​its​​neighbors.​​After​​a​​pulse,​​the​​process​​continues​​with​​the​​next​​available​
​pulse​ ​node​ ​to​ ​the​ ​right​ ​of​ ​the​ ​destroyed​ ​zone.​ ​If​ ​the​ ​head​ ​of​ ​the​ ​list​ ​is​ ​destroyed,​​the​​first​​available​
​surviving​​node​​becomes​​the​​new​​head.​​Your​​goal​​is​​to​​complete​​the​​function​​sendPulse(CellNode​​head)​
​that​ ​takes​ ​the​ ​head​ ​of​ ​the​ ​linked​​list​​and​​returns​​the​​head​​of​​the​​final​​linked​​list​​after​​all​​pulses​​have​
​occurred.​
​Python Method Signature​
​Java Method Signature​
​def sendPulse( head ):​
​public static CellNode sendPulse( CellNode head )​
​Page​​1​​out of 3​


--- PAGE 2 ---
​Python CellNode Class​
​Java CellNode Class​
​class CellNode:​
​def __init__(self, val, radius):​
​self.val = val​
​self.pulse_radius = radius​
​self.next = None​
​self.prev = None​
​class CellNode {​
​int val;​
​int pulse_radius;​
​CellNode next;​
​CellNode prev;​
​}​
​Sample Given LinkedList​
​Sample Returned LinkedList​
​(5,0) <-> (10,1) <-> (15,0) <-> (20,0)​
​(20, 0)​
​Explanation:​​The​​pulse​​at​​(10,1)​​bursts,​​destroying​​its​​left​​neighbor​​(5,​​0),​​itself,​​and​​its​​right​​neighbor​
​(15,​​0).​​Since​​the​​first​​three​​nodes​​are​​removed,​​(20,​​0)​​is​​the​​only​​survivor​​and​​becomes​​the​​new​
​head.​
​(5,0) <-> (10,0) <-> (15,1) <-> (20,1) <-> (25,0)​
​(5, 0) <-> (25, 0)​
​Explanation:​ ​The​ ​pulse​ ​at​ ​(15,​ ​1)​ ​bursts,​ ​destroying​ ​its​ ​left​ ​neighbor​ ​(10,​ ​0),​ ​itself,​ ​and​ ​its​ ​right​
​neighbor (20, 1). The remaining survivors, (5, 0) and (25, 0), instantly snap together to form a new link.​
​Question 3: CO1 [6 Points]​
​At​ ​an​ ​airport,​ ​passengers​ ​line​ ​up​ ​in​ ​a​ ​queue​ ​to​ ​board​ ​a​ ​flight.​ ​According​ ​to​ ​the​​boarding​​policy,​
​passengers​​are​​processed​​in​​groups​​of​​k​.​​Before​​each​​group​​boards,​​the​​airline​​staff​​reverses​​the​
​order​​of​​passengers​​within​​that​​group​​for​​security​​verification.​​If​​the​​last​​group​​contains​​fewer​
​than​ ​k​ ​passengers​,​ ​their​ ​order​ ​remains​ ​unchanged​.​ ​Write​ ​a​ ​function/method​ ​named​
​queueGroupReverse()​​that​​reorganizes​​the​​queue​​according​​to​​this​​rule​​and​​returns​​the​​updated​
​queue​.​
​Assume​​that​​linked-list-based​​Stack​​and​​Queue​​are​​already​​provided​.​​The​​Stack​​class​​provides​​the​
​public​​methods​​push(),​​pop(),​​peek(),​​and​​isEmpty(),​​while​​the​​Queue​​class​​provides​​the​​public​​methods​
​enqueue(), dequeue(), peek(), and isEmpty(). The instance variables of these classes are​​private​.​
​You​​cannot​​use​​any​​data​​structure​​other​​than​​the​​given​​Stack​​and​​Queue​.​​However,​​you​​may​
​create​​multiple stacks or queues if necessary​.​
​Java Method Signature​
​Python Function Signature​
​public static Queue queueGroupReverse(Queue q, int k)​
​def queueGroupReverse(q, k):​
​Sample Given Queue​
​Sample Returned Queue​
​Explanation​
​Queue:​​1 2 3 4 5 6 7 8​
​k​​= 3​
​leftmost is the front​
​(front) 3 2 1 6 5 4 7 8​
​Passengers​
​are​
​processed​
​in​
​groups​​(1​​2​​3),​​(4​​5​​6),​​and​​(7​
​8).​ ​The​ ​first​ ​two​ ​groups​ ​are​
​reversed,​ ​while​ ​the​ ​last​ ​group​
​contains​ ​fewer​​than​​k​​passengers​
​and therefore remains unchanged.​
​Queue:​​5 8 11 14 17​
​k​​= 4​
​leftmost is the front​
​(front) 14 11 8 5 17​
​Passengers​
​are​
​processed​
​in​
​groups​​(5​​8​​11​​14)​​and​​(17).​​The​
​first​​group​​is​​reversed,​​and​​the​
​last​ ​passenger​ ​remains​ ​in​ ​the​
​same​ ​position​ ​since​ ​the​ ​group​
​size is less than k.​
​Page​​2​​out of 3​


--- PAGE 3 ---
​Question 4: CO3 [10 Points]​
​Answer the questions in your Answer Script​
​I.​A hash table of size 10 is used to store the following​​keys: 15, 25, 35, 45, 55, 65, 75.​
​Assume forward chaining will be used for collision handling. Following four hash functions are proposed:​
​H1(k) = k mod 10​
​H2(k) = (k / 10) mod 10​
​H3(k) = (k + 5) mod 10​
​H4(k) = (k * 2) mod 10​
​All the results will be in integer, if there are fractions the floor value is considered.​
​Which hash function is the best choice here to reduce the collision?​
​[1 mark]​
​(a) H1       (b) H2       (c) H3     (d) H4​
​II.​​What is the time complexity of traversing a linked​​list containing n nodes?​
​[1 mark]​
​(a) O(log(n))​
​(b) O(n)​
​(c) O(n^2)​ ​(d) O(n/2)​
​III.​​What data structures can not be used to reverse​​a queue?​
​[1 mark]​
​(a) Array​
​(b) LinkedList​
​(c) Queue​
​(d) Stack​
​IV.​​Given​​a​​stack,​​three​​push​​functions​​push(1),​​push(2),​​push(3)​​are​​being​​called.​​However,​​in​​between​
​these​ ​push()​ ​functions​ ​or​ ​at​ ​the​​end​​of​​calling​​these​​push()​​functions,​​three​​pop()​​functions​​are​​being​
​called. Which sequence of outputs can never be generated given this scenario?​
​[1 mark]​
​(a) 3 2 1​
​(b) 3 1 2​
​(c) 2 1 3​
​(d) 1 2 3​
​V.​ ​Given​ ​the​ ​following​ ​dummy-headed​ ​doubly​ ​circular​ ​linked​ ​list,​ ​where​ ​the​
​dummy​​head​​node​​is​​the​​node​​having​​null​​value.​​The​​modify(​​dh​​)​​function​​is​
​executed with dh(dummy head) passed as the argument:​
​After the function finishes executing, draw the resulting linked list in the answer​
​script.​
​[3 mark]​
​function modify(dh):​
​loop 2 times:​
​n1 = dh.next​
​n2 = n1.next​
​n3 = dh.prev​
​dh.next = n2​
​n2.prev = dh​
​n3.next = n1​
​n1.prev = n3​
​n1.next = dh​
​dh.prev = n1​
​VI.​​Which linked list’s head variable points to a​​node even when the list is empty?​
​[1 mark]​
​(a) Doubly Linked List​
​(b) Circular Linked List​
​(c) Singly Linked List​
​(d) Dummy Headed Linked List​
​VII.​​If a linear array​​of 500 length has been converted into a multi dimensional array of 10x5x10 shape.​
​What would be the multi dimensional index of linear index 341?​
​[2 mark]​
​Page​​3​​out of 3​

```



# bracu.cse220 - midTerm - fa24 A.pdf

```text
--- PAGE 1 ---
BRAC UNIVERSITY 
Department of Computer Science and Engineering 
Examination: Mid-Term 
Duration: 75 Minutes 
Number of Questions: 3 
CSE220: Data Structures 
Semester: Fall 2024 
Full Marks: 30 
  No. of Pages: 3 
 
●​ Answer all 3 questions. No washroom breaks.   
●​ At the end of the exam, put the question paper inside the answer script and return both. 
●​ For Java, just complete the function, no need to write the class and main method. 
 
Question 1: CO1 [2 + 8 Points] 
I.​
Suppose you are given a multi-dimensional array with dimensions 3x4x2. What is the 
linear index of the multidimensional index [2][1][0]? 
II.​
You have hidden a password into a square matrix for your friend. Only you know that the 
password can be achieved through traversing the array in a zigzag fashion. Now help 
your friend develop a function/method that will take the 2D array as input and print the 
password in the output console. 
Complete the function zig_zag which will take a NxN 2D array and print all the values in 
a zigzag pattern. Each value will be separated by a space. Assume the function will 
always receive a NxN 2D array. Your code should work for any NxN array. 
 
Input Array 
Output 
Zigzag traversal explanation 
 
|  D  |  B  |  G  |  S  | 
------------------------- 
|  A  |  G  |  T  |  S  | 
------------------------- 
|  W  |  U  |  R  |  N  | 
------------------------- 
|  O  |  H  |  R  |  O  | 
------------------------- 
 
D A B W G G O U T S 
H R S R N O  
 
 
 
Hint: You need to follow the arrowed line 1 to line 7 to find out the zigzag pattern. Use one loop 
to print the upper triangle (line 1 to 4) and another loop to print the lower triangle (line 5 to 7). 
Python Notation 
Java Notation 
def zig_zag(arr): 
     # To Do 
 
public void zig_zag(int[][] arr) { 
       // To Do 
} 
 
 
 
                                                               Page 1 of 3                                                            Set-A 
Name: 
 
(Please write in CAPITAL LETTERS) 
ID: 
Section:  


--- PAGE 2 ---
 
 
Question 2: CO5 [10 Points] 
 
You are given a non-dummy-headed, singly linear linked list containing positive integers. Your 
task is to complete the given method reverseAndSwap() that takes the head of the linked list 
and an integer i as input and returns the head of the modified list. 
 
Your task is to 
●​ Reverse the list from index 0 to i 
●​ Swap the two parts of the list, i.e., the unchanged part from index i + 1 to total_nodes – 1 
will come before the reversed part from index 0 to i in the new list. (where total_nodes = 
number of nodes in the linked list) 
Check the given input and output for more clarification. 
 
Note: You can assume that the index i will always be in the range 0 to total_nodes – 1. Assume 
Node class has elem and next variable. No need to write the Node class. 
 
[DO NOT USE OTHER DATA STRUCTURE OTHER THAN GIVEN LINKED LIST, i.e. YOU 
CANNOT CREATE A NEW LINKED LIST] 
 
Sample Input 
Sample Output 
Explanation 
5→7→6→3→8→2→1 
i = 3 
8→2→1→3→6→7→5 
The list is reversed from index 0 to 3 
producing 3→6→7→5. The unchanged 
part (8→2→1) now sits before the 
reversed part, producing the output list.  
5→7→6→3→8→2→1 
i = 0 
7→6→3→8→2→1→5 
The list is reversed in index 0, 
producing 5. The unchanged part 
(7→6→3→8→2→1) now sits before the 
reversed part, producing the output list.  
5→7→6→3→8→2→1 
i = 6 
1→2→8→3→6→7→5 
The list is reversed from index 0 to 6, 
there is no part from the original list left. 
5→7→6→3→8→2→1 
i = 5 
1→2→8→3→6→7→5 
The list is reversed from index 0 to 5 
producing 2→8→3→6→7→5. The only 
node remaining (Node 1) comes before 
the reversed part producing the output 
list.  
 
 
Python Notation 
Java Notation 
def reverseAndSwap(head, i): 
     # To Do 
 
public Node reverseAndSwap(Node head, int i) { 
       // To Do 
} 
 
 
                                                               Page 2 of 3                                                            Set-A 


--- PAGE 3 ---
 
Question 3: CO3 [10 Points] 
 
You are given the start and end time of some tasks. The tasks are sorted according to their 
starting time. You can merge two tasks A and B if they are overlapping. That is task B starts 
before the finishing time of  task A. In that case, it becomes a single task having the ending 
time of task A or task B (depending upon which task finishes later). This task can be merged 
further with other tasks if the above condition satisfies (overlapping). You want to merge as 
many tasks as possible and minimize the total number of non-overlapping tasks. 
You are given a 2D array named tasks storing the start and end time of the task. The array is 
sorted according to the starting time of the tasks. Each row of the array stores two integer 
values. The first value indicates the start time and the second value indicates the end time of a 
task. More specifically, the start and end time of the ith task is tasks[i][0] and tasks[i][1] 
respectively.  
Write a function named print_total_task(tasks) that takes the tasks array as input and 
prints the start time and end time for each non-overlapping task according to the given format. 
Note that the tasks are printed as decreasing order of start time. 
Consider that the Stack class is already available with the following methods/functions 
implemented: push(element), pop(), peek(), and isEmpty(). Stack Underflow and Stack Overflow 
exceptions return None (Python) / null(Java). There is no need to write the Stack class. 
You are allowed to create as many stacks as you want. You cannot create any new array. To 
create a Stack object use the following: 
stack = Stack()  #(Python)                  Stack stack = new Stack()  //(Java) 
Example 1: 
 
Input: 
tasks = [[1, 5],  
              [2, 3],  
              [4, 6],  
              [7, 10],  
              [9, 11],  
              [12, 15]] 
 
Output: 
12, 15 
7, 11 
1, 6 
 
Explanation: 
 
Tasks (1,5) and (2,3) are overlapping, so we can merge them creating the 
new task (1,5) 
Then task (1,5) and (4,6) are also overlapping, merging them creates the 
new task (1,6) 
We can not merge tasks (1,6) and (7,10) as they are non-overlapping​
However tasks (7,10) and (9,11) can be merged creating new task (7, 11)​
Finally tasks (7,11) and (12,15) are non-overlapping 
So we have 3 non-overlapping tasks ​
(1,6), (7,11) and (12,15) 
Tasks are printed in descending order of start time. 
 
 
 
                                                               Page 3 of 3                                                            Set-A 
Python Notation 
Java Notation 
def print_total_task(tasks): 
       # To Do 
public void print_total_task(int [ ][ ] tasks){ 
      // To Do 
} 

```



# bracu.cse220 - midTerm - su24 B.pdf

```text
--- PAGE 1 ---
BRAC UNIVERSITY
Department of Computer Science and Engineering
Examination: Mid-Term
Duration: 80 Minutes
Number of Questions: 3
CSE220: Data Structures
Semester: Summer
2024
Full Marks: 35
No. of Pages: 4
✔Answer all 3 questions. No washroom breaks.
✔At the end of the exam, put the question paper inside the answer script and return both.
Question 1: CO1 [2 + 8 Points]
I.
Suppose you are given a multi-dimensional array with dimensions 4x3x2x6. What is the
corresponding linear index of the multidimensional index [2][1][0][4]?
II.
Bob has already learnt about 2D matrices and its operations in the data structures
course. However, he is currently facing problems in rotating a 2D square matrix. As
such, he has asked you to help him solve the problem.
You should rotate the original input matrix's outer rows and columns in left, down, right,
top manner without affecting the internal cells; instead of creating a new matrix.
Here, as you can see, if you rotate the given square matrix anticlockwise, 1st row will
be 1st column, 1st column will be last row, last row will be last column and last column
will be 1st row. The elements of the internal cells will be unchanged.
So given a square matrix of size n*n, your task is to complete the given method
rotate(matrix) that takes a 2D square matrix as an input and returns the rotated matrix
using in-place algorithm.
Hints of in-place: Rotating by one element at a time instead of an entire
row/column
should eliminate the need for any supporting data structures.
Sample Input
Sample Output
|
1
|
2
|
3
|
-------------------
|
5
|
6
|
7
|
-------------------
|
9
|
10 |
11 |
-------------------
|
3
|
7
|
11 |
-------------------
|
2
|
6
|
10 |
-------------------
|
1
|
5
|
9
|
-------------------
Page 1 of 4
Set-B
Name:
(Please write in CAPITAL LETTERS)
ID:
Section:


--- PAGE 2 ---
Sample Input
Sample Output
|
1
|
2
|
3
|
4
|
-------------------------
|
5
|
6
|
7
|
8
|
-------------------------
|
9
|
10 |
11 |
12 |
-------------------------
|
13 |
14 |
15 |
16 |
-------------------------
|
4
|
8
|
12 |
16 |
-------------------------
|
3
|
6
|
7
|
15 |
-------------------------
|
2
|
10 |
11 |
14 |
-------------------------
|
1
|
5
|
9
|
13 |
-------------------------
Python Notation
Java Notation
def rotate(matrix):
# To Do
public int[][] rotate(int[][]matrix) {
// To Do
}
Question 2: CO5 [10 Points]
Suppose, you are working on a web application which has a customer support system. You are
assigned to handle the customer support tickets. The support tickets are stored in a non-dummy
headed singly linear linked list on a first-come first-served basis by IDs. However, due to a
glitch, some tickets have been duplicated. Now, your task is to complete the given method
remove_Duplicates(head) which takes the head of the linked list as input to remove the
duplicate IDs ensuring that each ticket appears only once.
[DO NOT USE OTHER DATA STRUCTURE OTHER THAN GIVEN LINKED LIST]
Sample Input
Sample Output
Explanation
Input Tickets:
101 -> 103 -> 101 -> 102 -> 103
-> 104 -> 105 -> 105
Fixed Tickets:
101 -> 103 -> 102 -> 104 -> 105
All the duplicates of 101, 103 and
105 have been removed.
Input Tickets:
102 -> 101 -> 101 -> 102 -> 102
-> 102 -> 103 -> 104 -> 104
Fixed Tickets:
102 -> 101 -> 103 -> 104
All the duplicates of 102, 101 and
104 have been removed.
Python Notation
Java Notation
def remove_Duplicates(head):
# To Do
public Node remove_Duplicates(Node head) {
// To Do
}
Page 2 of 4
Set-B


--- PAGE 3 ---
Question 3: CO3 [7+8 Points]
I.
You are given a stack of some integer elements, st. Your task is to swap the adjacent
elements of the stack and return the modified stack. If the number of elements in the
stack is odd, keep the topmost element as it is and swap the other adjacent elements.
See
the
input
output
for
better
understanding.
Now
write
a
function
Do_Adjacent_Swap(st) that completes the given task and returns the modified stack.
The st is an object of the “Stack” class which is implemented by a singly linear linked list
and consider that the following methods of “Stack” class are already implemented for
you: push(element), pop(), peek(), isEmpty().
You cannot use any other data structures other than stack. The “Top” pointer of Stack
class is NOT accessible to you. You can use just the above four methods of Stack class.
You can create as many stacks as you need for this task.
Sample Input
Sample Output
Explanation
Original Stack:
8(Top) →7 →6 →5 →4 →
3 →2 →1
Modified Stack:
7(Top) →8 →5 →6 →3 →4
→1 →2
Original Stack:
7(Top) →6 →5 →4 →3 →2
→1
Modified Stack:
7(Top) →5 →6 →3 →4 →1
→2
Python Notation
Java Notation
def Do_Adjacent_Swap(st):
# To Do
public Stack Do_Adjacent_Swap(Stack st): {
// To Do
}
Page 3 of 4
Set-B


--- PAGE 4 ---
II.
You are given a circular array-based queue where the length of the array is 4 and the
starting index of front and back is 3.
You need to perform the queue operations based on the function given below. This
function takes the head of a non-dummy-headed singly linear linked list and a queue
object as an input.
Linked_List = -1→5→-12→-20→9→-43→-67→-67→-85→-91→-90
def test(head,queue):
temp = head
while temp.next != None:
if temp.next.elem < temp.elem:
queue.enqueue(temp.next.elem)
elif temp.next.elem > temp.elem:
queue.dequeue()
else:
queue.peek()
temp = temp.next
Show the queue, front index and back index in the following table for each of the nodes.
The Print Message includes Queue Overflow, Queue Underflow, Peeked items and
Dequeued items.
No need to write anything in the Print Message when the enqueue operation is performed.
Fillup the following table in your answer script. No need to write in the question paper.
Temp Node
0
1
2
3
Front
Back
Print Message
Initial
3
3
Node -1
Node 5
Node -12
Node -20
Node 9
Node -43
Node -67
Node -67
Node -85
Node -91
Node -90
-
-
-
-
-
-
-
Page 4 of 4
Set-B

```



# bracu.cse220 - midTerm - fa25 A.pdf

```text
--- PAGE 1 ---
 
BRAC UNIVERSITY 
Department of Computer Science and Engineering 
Examination: Midterm 
Duration: 80 Minutes 
No. of Questions: 4 
CSE 220: Data Structures 
Semester: Fall 2025 
Full Marks: 30 
No. of Pages: 3 
 
 
Name: 
ID: 
Section: 
✔ Use the back part of the answer script for rough work. No washroom breaks. 
✔ At the end of the exam, put the question paper inside the answer script and return both. 
✔ Understanding questions is part of the exam. 
 
Question 1: CO5 [8 Points] 
You are exploring an energy grid matrix using a direction map matrix, both of which are of an m x n shape. 
●​ grid[x][y] – contains integer energy values where x , y are the indices. 
●​ directions[x][y] – contains String direction symbols: "NE", "NW", "SE", "SW". 
Each cell of the directions matrix tells you in which direction the energy comes to that specific coordinate of the 
grid matrix. Meaning, for the sample example below the (0,1) cell is getting energy from all the cells which are 
“South East” of itself where the values are 7,12. So, the (0,1) cell's energy is 2+7+12=21. 
Your task is to compute how much total energy each block absorbs by following the direction shown on the 
direction map. So, write a function/method blockEnergySum() that computes a new 
Energy Matrix where: 
●​ For each cell in the grid matrix, start from its own position. 
●​ Look at its direction symbol (i.e “SE” for [0,1]) in the directions matrix. Keep 
moving in that diagonal direction in the grid matrix until you exit the grid. 
●​ While moving, you sum up all visited cell values, including the starting cell of each 
cell. 
●​ Do this for all the cells of the grid matrix. Lastly, return the newly computed 
Energy Matrix where each of the cells contain the energy summations of each 
respective cell of the grid matrix. 
Note: The space complexity of your solution must not exceed O(m*n). 
Given Matrices 
Returned Energy Matrix  
grid = 
 
directions =  
 
34 
21 
18 
4 
5 
15 
11 
8 
9 
23 
19 
21 
13 
23 
15 
16 
 
1 
2 
3 
4 
 
“SE” 
“SE” 
“SW” 
“NE” 
5 
6 
7 
8 
 
“SW” 
“SW” 
“NE” 
“SE” 
9 
10 
11 
12 
 
“NW” 
“SW” 
“NE” 
“NW” 
13 
14 
15 
16 
 
“SE” 
“NW” 
“SW” 
“NE” 
 
Explanation 
[0,0]⇒ SE: includes its own value 1 then SE path adds 6,11,16 ⇒ 1+(6+11+16) = 34 
[0,1]⇒ SE: includes its own value 2 then SE path adds 7,12 ⇒ 2+(7+12) = 21 
[0,2]⇒ SW: includes its own value 3 then SW path adds 6,9 ⇒ 3+(6+9) = 18 
[0,3]⇒ NE: includes its own value 4 but moving NE immediately exits the grid, so no additional cells 
are 
   added ⇒ total energy = 4 which is shown in the corresponding index of returned Energy Matrix. 
[1,0]⇒ SW: same as [0,3] since the “SW” direction also exits the grid ⇒ total energy = 5. 
[1,1]⇒ SW: includes its own value 6, then SW path adds 9 ⇒ 6+(9) = 15. 
Other cells follow the same process: summing the cell's own value & cells along its diagonal direction. 
Java Method Signature 
Python Function Signature 
static int[][] blockEnergySum( int[][] grid, String[][] directions ){ 
//TODO 
} 
def blockEnergySum( grid , directions ) 
#TODO 
 


--- PAGE 2 ---
 
 
Question 2: CO1 [8 Points] 
 
Write a function/method named rangeReverse() that takes the head of a dummy-headed singly linked list and two 
integers as parameters. The two integers represent a starting index and an ending index. 
You need to reverse the nodes within the given range. Furthermore, the nodes that lie outside the given range must 
remain in their original order and be appended after the reversed segment. Please note that this is an in-place 
operation meaning you cannot create any new nodes. 
No need to write Node class. Assume, the Node class is already defined and contains: int elem and Node next. 
You cannot create any new nodes to solve this task. 
Given Linked List 
Modified Linked List 
Explanation 
[DH]⇒3⇒5⇒8⇒7⇒2⇒1⇒6⇒4⇒
2 
start = 2, end = 5 
[DH]⇒1⇒2⇒7⇒8⇒3⇒5⇒6⇒4
⇒2 
Nodes from indices 2 to 5 were 
reversed and moved to the start. All 
other nodes remained in place and 
were appended after the reversed 
part. 
[DH]⇒3⇒5⇒8⇒7⇒2⇒1⇒6⇒4⇒
5 
start = 4, end = 12 
[DH]⇒5⇒4⇒6⇒1⇒2⇒3⇒5⇒8
⇒7 
Nodes from indices 4 to 8 were 
reversed and moved to the start. All 
other nodes remained in place and 
were appended afterward. The end 
index 12 was ignored as it was 
outside the valid range. 
Java Method Signature 
Python Function Signature 
static void rangeReverse( Node dHead, int start, int end ){ 
   // TODO 
} 
def rangeReverse( dHead, start, end ) 
#TODO 
 
Question 3: CO1 [6 Points] 
 
You are given two stacks, each sorted in non-decreasing order from top to bottom. Your task is to implement a 
function named mergeStacks() that merges the two stacks into a single stack and finally returns the merged stack. 
The merged stack also must be in non-decreasing order. 
No need to write the Stack class. Assume, a linked list based stack is already implemented for you. Its public 
instance methods are push(), pop(), peek(), and isEmpty(). The instance variables of this class are private. 
 
You cannot use any data structure other than the stack. You can create as many stacks as you want. 
Given Stacks 
Returned Stack 
Explanation 
stack1 = -2 3 6 6 10 
stack2 = 0 4 6 8 
stack = -2 0 3 4 6 6 6 8 10 
Both 
stack1 
and 
stack2 
are 
in 
non-decreasing order. They are merged 
into a stack, and the merged stack is 
also in non-decreasing order. 
Here, the leftmost value is the top 
 
Java Stack Creation 
Python Stack Creation 
Stack stk = new Stack(); 
stk = Stack() 
Java Method Signature 
Python Method Signature 
static Stack mergeStacks(Stack stack1, Stack stack2) { 
    // TODO 
} 
def mergeStacks(stack1, stack2): 
    # TODO 
 
 


--- PAGE 3 ---
 
 
Question 4: CO3 [8 Points] 
Answer the questions in your Answer Script 
 
i.​
Suppose you are given a multi-dimensional array with dimensions 6x4x8.  
What is the linear index of [4][2][5] multidimensional index? ​
​
​
​
​
[2 points] 
 
ii.​
In a linked list based queue, what is the time complexity of getting the first inserted element?​​
[1 point] 
a.​ O(1) 
b.​ O(n) 
c.​ O(log(n)) 
d.​ O(n2) 
 
iii.​
In a NxN 2D array, what will be the time complexity if we want to calculate the sum of the elements of the left 
diagonal in the most efficient way? ​​
​
​
​
​
​
​
​
[1 point] 
a.​ O(log(n)) 
b.​ O(2n) 
c.​ O(n) 
d.​ O(n2) 
 
iv.​
For the hash table shown on the right, what can be a possible sequence in 
which the key value pairs are inserted? Here, the integer values are keys. 
Collision is resolved by appending a new item at the end. 
[Hash Function = key%hash table length] ​ ​
​
[2 points] 
a.​ (8, D), (12, A), (9, B), (6, M), (14, N) 
b.​ (12, A), (6, M), (14, N), (8, D), (9, B) 
c.​ (14, N), (9, B), (6, M), (8, D), (12, A) 
d.​ (14, N), (9, B), (6, M), (12, A), (8, D) 
 
v.​
Your two friends suggest the following hash functions to map integer keys into a hash table of length n: 
➢​ friend 1’s hash function = key*2 % n 
➢​ friend 2’s hash function = key % (n/2) 
Being a student who learned HashTable data structure, evaluate the 2 functions and find out: 
a.​ What is the potential problem (if any) with Friend 1’s hash function?​
​
​
​
[1 point] 
b.​ What is the potential problem (if any) with Friend 2’s hash function?​
​
​
​
[1 point] 
Provide a one-line answer for each of the two questions above. 
 
 

```
