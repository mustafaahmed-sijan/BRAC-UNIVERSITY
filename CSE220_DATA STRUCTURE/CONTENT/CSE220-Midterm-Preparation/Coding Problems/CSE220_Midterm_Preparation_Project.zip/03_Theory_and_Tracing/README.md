# Theory and tracing questions

This section collects non-method theory and manual-tracing tasks from the papers. These should not be mislabeled as MCQs.

## Topics found
- Row-major multidimensional array index conversion (2D, 3D, 4D)
- Array versus linked-list disadvantages and memory overhead
- Stack push/pop sequence validity
- Stack and queue ADT operations
- Circular array queue front/back wraparound, overflow and underflow
- Dummy-headed versus non-dummy-headed linked lists
- Doubly circular linked-list pointer tracing
- Hash function quality, collision handling, chaining and load factor
- Time complexity of diagonal traversal, list traversal and queue front access

## Important formulas
For row-major 2D array with `c` columns:
`linear = row*c + col`

For row-major 3D array with dimensions `d1 × d2 × d3`:
`linear = i*(d2*d3) + j*d3 + k`

For row-major 4D:
`linear = i*(d2*d3*d4) + j*(d3*d4) + k*d4 + l`

Convert linear index `L` back to 3D:
`i = L/(d2*d3)`, remainder `r = L%(d2*d3)`, `j = r/d3`, `k = r%d3`.

## Circular queue trace method
For each operation:
1. Write the current array and front/back indices.
2. Enqueue: if full, report overflow; otherwise advance back with `(back+1)%capacity` and insert.
3. Dequeue: if empty, report underflow; otherwise remove front and advance front with modulo.
4. Peek: report the front value without changing indices.
5. Do not update indices for a failed operation.

## Doubly circular list pointer trace
For every statement, record `dh.next`, `dh.prev`, `n1.next`, `n1.prev`, `n2.prev`, and `n3.next`. In a circular list, the last node links back to dummy head and the first node's prev points to dummy head.
