# Additional Practice MCQs

At least 10 fresh questions per topic. These are concept variations, not just changed numeric values. Answers include Bangla explanations.

## Array and Matrix

### 1. A row-major 2D array has 4 columns. What is the linear offset of [2][1]?
- A. 9
- B. 6
- C. 5
- D. 10

**Answer: A.** offset = row*columns+column = 2*4+1 = 9.

### 2. Which traversal visits every element of an r×c matrix exactly once?
- A. Diagonal only
- B. Nested row/column loops
- C. Main diagonal
- D. Boundary only

**Answer: B.** Nested loops cover all r*c positions.

### 3. What is the time complexity of finding the maximum in an unsorted n-element array? 
- A. O(1)
- B. O(log n)
- C. O(n)
- D. O(n²)

**Answer: C.** প্রতিটি element check করতে হয়।

### 4. Which index pair represents the main diagonal in a square matrix?
- A. [i][n-i]
- B. [i][i]
- C. [0][i]
- D. [i][0]

**Answer: B.** Main diagonal-এ row এবং column index সমান।

### 5. A matrix is rotated in-place. What does in-place primarily restrict?
- A. No loops
- B. No new matrix-sized storage
- C. No variables
- D. No condition

**Answer: B.** অতিরিক্ত matrix-sized storage ব্যবহার করা যাবে না।

### 6. For an m×n matrix, how many elements are on its main diagonal?
- A. m+n
- B. m*n
- C. min(m,n)
- D. max(m,n)

**Answer: C.** Diagonal ছোট dimension শেষ হওয়া পর্যন্ত যায়।

### 7. Which operation is O(1) in a normal array when accessing by valid index?
- A. Search unsorted value
- B. Read arr[i]
- C. Insert at front
- D. Delete at front

**Answer: B.** Direct index access constant time.

### 8. A 2×2 block compression sums four cells into one. What is the output shape for an even r×c matrix?
- A. r×c
- B. r/2 × c/2
- C. 2r×2c
- D. r+c

**Answer: B.** প্রতি 2 row ও 2 column একটি output cell তৈরি করে।

### 9. What is the best way to sum the left diagonal of an n×n matrix?
- A. Two nested loops
- B. One loop using [i][i]
- C. Sort each row
- D. Traverse columns twice

**Answer: B.** nটি diagonal cell একবার করে যোগ হয়।

### 10. Which condition ends a diagonal walk toward south-east?
- A. row < 0
- B. column < 0
- C. row >= rows or column >= columns
- D. row == column

**Answer: C.** Grid boundary অতিক্রম করলেই traversal থামে.

## Linked List

### 1. What is the time complexity of accessing the kth node in a singly linked list?
- A. O(1)
- B. O(log n)
- C. O(n)
- D. O(n²)

**Answer: C.** Head থেকে একে একে next follow করতে হয়।

### 2. In a dummy-headed list, where does the first data node usually begin?
- A. head
- B. head.next
- C. head.prev
- D. null

**Answer: B.** Dummy node-এর পরের node হলো first data node।

### 3. Which pointer must be updated when deleting the first node of a non-dummy singly list?
- A. tail only
- B. head
- C. every next pointer
- D. none

**Answer: B.** Head নতুন first node-এ সরাতে হয়।

### 4. What is the main advantage of a doubly linked list over a singly linked list?
- A. Less memory
- B. Backward traversal
- C. O(1) random access
- D. No pointers

**Answer: B.** prev pointer থাকার কারণে backward traversal সম্ভব।

### 5. How can duplicates be removed without an extra data structure?
- A. Sort only
- B. Nested traversal and unlink later matches
- C. Use HashSet
- D. Copy to array

**Answer: B.** প্রতিটি node-এর পরের অংশ scan করে duplicate unlink করা যায়।

### 6. What must be updated when removing a middle node x?
- A. previous.next = x.next
- B. head = x.next always
- C. x.prev = null only
- D. tail = x

**Answer: A.** আগের node-কে পরের node-এর সাথে link করতে হয়।

### 7. What is the time complexity of traversing n nodes?
- A. O(1)
- B. O(log n)
- C. O(n)
- D. O(n²)

**Answer: C.** প্রতিটি node visit করা হয়।

### 8. A linked list has one node. What is its last node's next value in a linear list?
- A. head
- B. itself
- C. null
- D. dummy

**Answer: C.** Linear list শেষ হয় null-এ।

### 9. Why is insertion at head O(1)?
- A. No pointer update
- B. Only new.next and head change
- C. Requires traversal
- D. Requires sorting

**Answer: B.** কোনো traversal লাগে না।

### 10. What is a safe way to reverse a singly linked list iteratively?
- A. Use prev,current,next pointers
- B. Swap data only always
- C. Sort nodes
- D. Use binary search

**Answer: A.** প্রতিটি next link উল্টে দেওয়া হয়।

## Stack and Queue

### 1. Which principle does a stack follow?
- A. FIFO
- B. LIFO
- C. Random
- D. Priority

**Answer: B.** Last In First Out.

### 2. Which principle does a queue follow?
- A. LIFO
- B. FIFO
- C. Sorted
- D. Binary

**Answer: B.** First In First Out.

### 3. What does pop() do on a stack?
- A. Reads bottom
- B. Removes top
- C. Adds top
- D. Removes bottom

**Answer: B.** Top element remove ও return করে।

### 4. What does peek() do?
- A. Removes top
- B. Reads top without removal
- C. Adds element
- D. Clears stack

**Answer: B.** Peek শুধু top দেখে।

### 5. Why use a stack to reverse a queue?
- A. FIFO
- B. LIFO reverses order
- C. It sorts
- D. It hashes

**Answer: B.** Stack pop করলে reverse order পাওয়া যায়।

### 6. A circular queue of length n advances back using which expression?
- A. back+1
- B. (back+1)%n
- C. back-1
- D. back*n

**Answer: B.** Modulo index-কে 0..n-1 এর মধ্যে রাখে।

### 7. What is queue underflow?
- A. Insert into full queue
- B. Remove from empty queue
- C. Peek full queue
- D. Wraparound

**Answer: B.** Empty queue থেকে dequeue করা underflow।

### 8. If k items are pushed then popped, what is the pop order?
- A. Same as push
- B. Reverse of push
- C. Sorted
- D. Undefined

**Answer: B.** Stack LIFO।

### 9. What happens to the last incomplete group in the Spring 2026 queue task?
- A. Always reversed
- B. Discarded
- C. Left unchanged
- D. Sorted

**Answer: C.** প্রশ্নে k-এর কম passenger-এর order unchanged।

### 10. How can adjacent stack elements be swapped without accessing internal pointers?
- A. Use stack operations and auxiliary stacks
- B. Use array index
- C. Read top pointer
- D. Use linked-list next directly

**Answer: A.** শুধু push/pop/peek/isEmpty ব্যবহার করতে হবে।

## Hash Table

### 1. What is a collision in hashing?
- A. Two keys map to same index
- B. Key is negative
- C. Array is sorted
- D. Table is empty

**Answer: A.** একাধিক key একই bucket/index পায়।

### 2. Separate chaining stores collisions using what?
- A. Linked lists/bucket chains
- B. Binary search only
- C. Stack only
- D. Matrix

**Answer: A.** প্রতিটি bucket-এ chain রাখা হয়।

### 3. What does key % tableLength compute?
- A. Key value
- B. Hash index
- C. Load factor
- D. Collision count

**Answer: B.** Modulo table-এর valid index তৈরি করে।

### 4. If table length is 12, what indices can key*2 % 12 produce?
- A. All indices
- B. Only even indices
- C. Only odd indices
- D. Only index 0

**Answer: B.** 2 দিয়ে গুণ করলে modulo 12-এর ফল even হয়।

### 5. What is the load factor?
- A. n/m only
- B. number of stored keys / table capacity
- C. capacity squared
- D. collision count

**Answer: B.** Stored entries divided by table capacity.

### 6. In sorted separate chaining, where should a new smaller key be inserted?
- A. At chain head if smaller than head
- B. Always tail
- C. At next bucket
- D. Delete chain

**Answer: A.** Ascending order রাখতে সঠিক position-এ insert করতে হয়।

### 7. If duplicate key is inserted and rule says replace, what changes?
- A. Add another node
- B. Update existing value
- C. Change bucket size
- D. Rehash all keys

**Answer: B.** একই key-এর value overwrite হবে।

### 8. What is a major risk of a poor hash function?
- A. More collisions
- B. No memory
- C. No keys
- D. O(1) always

**Answer: A.** Keys একই bucket-এ জমা হতে পারে।

### 9. What is expected search time with a good hash distribution and chaining?
- A. O(1) average
- B. O(n²) average
- C. O(log n) always
- D. O(n!)

**Answer: A.** ভালো distribution-এ chain ছোট থাকে।

### 10. Why is key % (n/2) poor for a table of length n?
- A. Uses upper half only
- B. Leaves upper half indices unused
- C. Always negative
- D. Cannot return integer

**Answer: B.** Index শুধু প্রথম অর্ধেকে পড়ে।

## Complexity and Tracing

### 1. A single loop visits n items. What is its time complexity?
- A. O(1)
- B. O(log n)
- C. O(n)
- D. O(n²)

**Answer: C.** n iteration।

### 2. Two nested loops each run n times. Complexity?
- A. O(n)
- B. O(n²)
- C. O(log n)
- D. O(1)

**Answer: B.** n*n iteration।

### 3. A loop halves n each iteration. Complexity?
- A. O(n)
- B. O(n²)
- C. O(log n)
- D. O(1)

**Answer: C.** প্রতি ধাপে input অর্ধেক হয়।

### 4. What is the space complexity of creating an m×n result matrix?
- A. O(1)
- B. O(m+n)
- C. O(mn)
- D. O(log n)

**Answer: C.** m*n output cells allocate হয়।

### 5. What does a dry run show?
- A. Only final answer
- B. Variable and structure changes step by step
- C. Compiler version
- D. Memory address

**Answer: B.** প্রতিটি iteration-এর state trace করা হয়।

### 6. In a queue trace, enqueue changes which index?
- A. front only
- B. back (and maybe front when empty)
- C. neither
- D. both always

**Answer: B.** নতুন item rear/back-এ যোগ হয়।

### 7. In a stack trace, which element is removed first?
- A. Bottom
- B. Top
- C. Middle
- D. Smallest

**Answer: B.** Pop top remove করে।

### 8. If a function traverses a list twice sequentially, complexity is?
- A. O(n²)
- B. O(2n), simplified O(n)
- C. O(log n)
- D. O(1)

**Answer: B.** দুইটি linear pass-ও O(n)।

### 9. What is the complexity of checking all pairs using nested linked-list traversal?
- A. O(1)
- B. O(n)
- C. O(n²)
- D. O(log n)

**Answer: C.** প্রতিটি node-এর জন্য অন্য node scan করলে quadratic।

### 10. What does amortized analysis measure?
- A. One worst operation only
- B. Average cost over a sequence of operations
- C. Only memory
- D. Compiler speed

**Answer: B.** একাধিক operation-এর মোট cost ভাগ করে দেখা হয়।
