# Original MCQs and theory questions from the papers

> The papers are not MCQ-only exams. Most questions are coding or short-answer questions. The following are the multiple-choice items that are readable in the PDFs. Questions whose answer depends on an unavailable embedded figure are flagged.

## Fall 2025 — Question 4

### ii. Linked-list queue
**Question:** In a linked-list based queue, what is the time complexity of getting the first inserted element?
- A. O(1)
- B. O(n)
- C. O(log(n))
- D. O(n²)

**Answer: A — O(1).**  
**বাংলা ব্যাখ্যা:** Queue FIFO। Linked-list queue-তে front pointer থাকলে প্রথম inserted element front-এ থাকে। Pointer access করতে traversal লাগে না, তাই O(1)।

### iii. Left diagonal sum
**Question:** In an N×N 2D array, what is the time complexity of calculating the sum of the left diagonal in the most efficient way?
- A. O(log(n))
- B. O(2n)
- C. O(n)
- D. O(n²)

**Answer: C — O(n).**  
**বাংলা ব্যাখ্যা:** বাম diagonal-এর element হলো `arr[i][i]`। একটি loop-এ nটি element যোগ করলেই হয়। তাই O(n), পুরো matrix traverse করতে হয় না।

### iv. Hash-table insertion order
**Question:** For the shown hash table, which insertion sequence is possible? Hash function is `key % table length`, and collisions are resolved by appending at the end.
- A. (8,D), (12,A), (9,B), (6,M), (14,N)
- B. (12,A), (6,M), (14,N), (8,D), (9,B)
- C. (14,N), (9,B), (6,M), (8,D), (12,A)
- D. (14,N), (9,B), (6,M), (12,A), (8,D)

**Answer:** Cannot be determined reliably from extracted text alone. The referenced hash-table diagram on the right side of the PDF is required. Do not guess.

### v. Evaluate two hash functions
**Question:** For a table of length n, evaluate:
- Friend 1: `key * 2 % n`
- Friend 2: `key % (n/2)`

**Answer and explanation:**
- Friend 1: If n is even, multiplying by 2 makes every computed index even, so roughly half the table indices are unreachable.
- Friend 2: It maps keys only into the range `0` through `n/2 - 1`, leaving the upper half of the table unused (assuming integer division and the stated table length).

## Spring 2026 — Question 4

### I. Best hash function
Keys: 15, 25, 35, 45, 55, 65, 75; table size 10; forward chaining.
- H1(k) = k mod 10
- H2(k) = (k / 10) mod 10
- H3(k) = (k + 5) mod 10
- H4(k) = (k * 2) mod 10

Options: A. H1, B. H2, C. H3, D. H4.

**Answer: B — H2.**  
**বাংলা ব্যাখ্যা:** H1, H3 এবং H4-এ এই key-গুলো একই index-এ collide করে। H2-তে floor(k/10) ব্যবহার করলে key-গুলো ভিন্ন bucket-এ ছড়ায়: 1,2,3,4,5,6,7। তাই collision কম।

### II. Linked-list traversal
**Question:** Time complexity of traversing a linked list containing n nodes?
- A. O(log(n))
- B. O(n)
- C. O(n²)
- D. O(n/2)

**Answer: B — O(n).**  
**বাংলা ব্যাখ্যা:** প্রতিটি node একবার করে visit করতে হয়। nটি node হলে nটি step, তাই O(n)।

### III. Reverse a queue
**Question:** Which data structure cannot be used to reverse a queue?
- A. Array
- B. LinkedList
- C. Queue
- D. Stack

**Answer: C — Queue.**  
**বাংলা ব্যাখ্যা:** Queue নিজেই FIFO; শুধু queue operation ব্যবহার করলে LIFO reverse behavior পাওয়া যায় না। Stack-এর LIFO property queue reverse করতে কাজে লাগে।

### IV. Stack output sequence
**Question:** Push(1), Push(2), Push(3) are called in that order, with three pop operations interleaved or after them. Which output can never occur?
- A. 3 2 1
- B. 3 1 2
- C. 2 1 3
- D. 1 2 3

**Answer: B — 3 1 2.**  
**বাংলা ব্যাখ্যা:** 3 pop করার পর stack-এ 2 উপরে থাকবে। 1 pop করার আগে 2-কে pop না করে 1 পাওয়া সম্ভব নয়। তাই 3,1,2 invalid।

### VI. Empty-list head
**Question:** Which linked list's head variable points to a node even when the list is empty?
- A. Doubly Linked List
- B. Circular Linked List
- C. Singly Linked List
- D. Dummy Headed Linked List

**Answer: D — Dummy Headed Linked List.**  
**বাংলা ব্যাখ্যা:** Dummy-headed list-এ data node না থাকলেও dummy node থাকে। তাই head/dummy reference null হয় না।

### VII. Linear to multidimensional index
**Question:** A linear array of 500 length is converted into a 10×5×10 array. Find the multidimensional index of linear index 341.

**Answer: [6][4][1] (row-major, zero-based).**  
**বাংলা breakdown:** 10×5×10 হলে last dimension দ্রুত পরিবর্তিত হয়। `341 / 50 = 6 remainder 41`; `41 / 10 = 4 remainder 1`; তাই `[6][4][1]`।

## Spring 2024 — Stack push/pop sequence

**Question:** Push 0 through 9 in order. Which sequences could not occur?
A. 1 2 3 4 5 6 9 8 7 0  
B. 0 4 6 5 3 8 1 7 2 9  
C. 1 4 7 9 8 6 5 3 0 2  
D. 2 1 4 3 6 5 8 7 9 0

**Answer: B and C cannot occur.**  
**বাংলা ব্যাখ্যা:** Stack-এ যে item উপরে আছে, সেটি pop না করে তার নিচের item pop করা যায় না। B-তে 6 pop করার পর 5,3 pop হয়, কিন্তু 4,2,1-এর অবস্থান পরে অসঙ্গত হয়; C-তেও 9 pop করার পর 8,6,5,3 ইত্যাদির ক্রমে stack constraint ভাঙে। এই প্রশ্নে প্রতিটি sequence-কে push/pop simulation দিয়ে যাচাই করতে হবে।
