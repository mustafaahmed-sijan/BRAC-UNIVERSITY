# CSE220 Midterm Preparation

## Source inventory
This project was built from the 8 PDFs in the uploaded ZIP.

| Paper | Source PDF |
|---|---|
| Fall_2023 | `bracu.cse220 - midTerm - fa23 A.pdf` |
| Spring_2024 | `bracu.cse220 - midTerm - sp24 A.pdf` |
| Summer_2024 | `bracu.cse220 - midTerm - su24 B.pdf` |
| Fall_2024 | `bracu.cse220 - midTerm - fa24 A.pdf` |
| Summer_2025 | `CSE220 Midterm Summer-25 Set-A.pdf` |
| Fall_2025 | `CSE220 Midtem Fall-25 Set-A.pdf` |
| Fall_2025_duplicate | `bracu.cse220 - midTerm - fa25 A.pdf` |
| Spring_2026 | `CSE220 Midtem Spring-26 Set-A.pdf` |

## Project map
- `01_MCQ_Question_Bank/Original_MCQs.md`: source MCQ and theory questions transcribed where readable, with answers.
- `01_MCQ_Question_Bank/Additional_Practice_MCQs.md`: new practice questions grouped by topic. These are newly authored, not copied from papers.
- `02_Coding_Problems/`: one folder per coding problem; each folder has an independent `Main.java` and a Bangla `README.md`.
- `03_Theory_and_Tracing/`: short-answer theory and tracing topics that are not programming-method questions; `Original_Paper_Text_Appendix.md` preserves extracted text from all 8 PDFs.
- Every Java folder is standalone. Open that folder in VS Code and run `javac Main.java` followed by `java Main`.

## Important source limitations
Some paper figures/tables are image-based and text extraction does not preserve all visual details. Where a question depends on a missing diagram (for example, a hash-table layout or a linked-list diagram), the README marks the exact limitation instead of inventing the missing figure.
The two Fall 2025 PDFs appear to cover the same Fall 2025 paper; they are recorded separately in the inventory but duplicate questions are not duplicated in the coding folders.

## Learning format
Each coding README follows this order: Bangla problem explanation, logic breakdown, dry run, code walkthrough, complexity, and exam variations. Java source files include comments and their own `main` method.
